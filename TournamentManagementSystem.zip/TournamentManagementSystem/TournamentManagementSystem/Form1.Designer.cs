﻿namespace TournamentManagementSystem
{
    partial class frmMain
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.lblMainInfo = new System.Windows.Forms.Label();
            this.panel1 = new System.Windows.Forms.Panel();
            this.lblDBConn = new System.Windows.Forms.Label();
            this.lblDateTime = new System.Windows.Forms.Label();
            this.pnlGeneralInfo = new System.Windows.Forms.Panel();
            this.lblLastCreated = new System.Windows.Forms.Label();
            this.lblCoachInfo = new System.Windows.Forms.Label();
            this.lblTeamsInfo = new System.Windows.Forms.Label();
            this.tabTeamsMain = new System.Windows.Forms.TabControl();
            this.tabNewTeam = new System.Windows.Forms.TabPage();
            this.lblEmailNewTeam = new System.Windows.Forms.Label();
            this.lblContactNewTeam = new System.Windows.Forms.Label();
            this.lblCityNewTeam = new System.Windows.Forms.Label();
            this.lblZipNewTeam = new System.Windows.Forms.Label();
            this.lblAddress2NewTeam = new System.Windows.Forms.Label();
            this.lblAddressNewTeam = new System.Windows.Forms.Label();
            this.lblTeamName = new System.Windows.Forms.Label();
            this.btnCancelNewTeam = new System.Windows.Forms.Button();
            this.btnAddTeam = new System.Windows.Forms.Button();
            this.txtTeamNewEmail = new System.Windows.Forms.TextBox();
            this.txtTeamNewPhone = new System.Windows.Forms.TextBox();
            this.txtTeamNewCity = new System.Windows.Forms.TextBox();
            this.txtTeamNewZip = new System.Windows.Forms.TextBox();
            this.txtTeamNewAddress2 = new System.Windows.Forms.TextBox();
            this.txtTeamNewAddress = new System.Windows.Forms.TextBox();
            this.txtTeamNewDirector = new System.Windows.Forms.TextBox();
            this.txtTeamNewCoach = new System.Windows.Forms.TextBox();
            this.txtTeamNewName = new System.Windows.Forms.TextBox();
            this.tabTeamsSearch = new System.Windows.Forms.TabPage();
            this.tabAboutTeams = new System.Windows.Forms.TabPage();
            this.lblCoachNameNewTeam = new System.Windows.Forms.Label();
            this.lblDirectorNewTeam = new System.Windows.Forms.Label();
            this.lblNewTeamInfo = new System.Windows.Forms.Label();
            this.lblNewTeamError = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.label8 = new System.Windows.Forms.Label();
            this.label9 = new System.Windows.Forms.Label();
            this.txtSearchEmail = new System.Windows.Forms.TextBox();
            this.txtSearchPhone = new System.Windows.Forms.TextBox();
            this.txtSearchCity = new System.Windows.Forms.TextBox();
            this.txtSearchZip = new System.Windows.Forms.TextBox();
            this.txtSearchAddress2 = new System.Windows.Forms.TextBox();
            this.txtSearchAddress = new System.Windows.Forms.TextBox();
            this.txtSearchDirector = new System.Windows.Forms.TextBox();
            this.txtSearchCoach = new System.Windows.Forms.TextBox();
            this.txtSearchName = new System.Windows.Forms.TextBox();
            this.radioAllTeams = new System.Windows.Forms.RadioButton();
            this.radioAllCoach = new System.Windows.Forms.RadioButton();
            this.radioAllDirector = new System.Windows.Forms.RadioButton();
            this.btnSearch = new System.Windows.Forms.Button();
            this.btnSearchClear = new System.Windows.Forms.Button();
            this.pnlReport = new System.Windows.Forms.Panel();
            this.dgvSearch = new System.Windows.Forms.DataGridView();
            this.label10 = new System.Windows.Forms.Label();
            this.label11 = new System.Windows.Forms.Label();
            this.label12 = new System.Windows.Forms.Label();
            this.label13 = new System.Windows.Forms.Label();
            this.label14 = new System.Windows.Forms.Label();
            this.label15 = new System.Windows.Forms.Label();
            this.label16 = new System.Windows.Forms.Label();
            this.label17 = new System.Windows.Forms.Label();
            this.label18 = new System.Windows.Forms.Label();
            this.txtReportEmail = new System.Windows.Forms.TextBox();
            this.txtReportPhoneNumber = new System.Windows.Forms.TextBox();
            this.txtReportCity = new System.Windows.Forms.TextBox();
            this.txtReportZip = new System.Windows.Forms.TextBox();
            this.txtReportAddress2 = new System.Windows.Forms.TextBox();
            this.txtReportAddress = new System.Windows.Forms.TextBox();
            this.txtReportDirector = new System.Windows.Forms.TextBox();
            this.txtReportCoach = new System.Windows.Forms.TextBox();
            this.txtReportName = new System.Windows.Forms.TextBox();
            this.btnReportUpdate = new System.Windows.Forms.Button();
            this.btnReportDelete = new System.Windows.Forms.Button();
            this.lblReportTextID = new System.Windows.Forms.Label();
            this.lblReportID = new System.Windows.Forms.Label();
            this.btnReportEdit = new System.Windows.Forms.Button();
            this.btnSearchExport = new System.Windows.Forms.Button();
            this.panel1.SuspendLayout();
            this.pnlGeneralInfo.SuspendLayout();
            this.tabTeamsMain.SuspendLayout();
            this.tabNewTeam.SuspendLayout();
            this.tabTeamsSearch.SuspendLayout();
            this.pnlReport.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgvSearch)).BeginInit();
            this.SuspendLayout();
            // 
            // lblMainInfo
            // 
            this.lblMainInfo.AutoSize = true;
            this.lblMainInfo.Font = new System.Drawing.Font("Microsoft JhengHei", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblMainInfo.Location = new System.Drawing.Point(13, 13);
            this.lblMainInfo.Name = "lblMainInfo";
            this.lblMainInfo.Size = new System.Drawing.Size(271, 21);
            this.lblMainInfo.TabIndex = 0;
            this.lblMainInfo.Text = "Tournament Management System";
            // 
            // panel1
            // 
            this.panel1.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.panel1.Controls.Add(this.lblDBConn);
            this.panel1.Controls.Add(this.lblDateTime);
            this.panel1.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.panel1.Location = new System.Drawing.Point(0, 645);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(752, 24);
            this.panel1.TabIndex = 1;
            // 
            // lblDBConn
            // 
            this.lblDBConn.AutoSize = true;
            this.lblDBConn.Location = new System.Drawing.Point(279, 4);
            this.lblDBConn.Name = "lblDBConn";
            this.lblDBConn.Size = new System.Drawing.Size(86, 13);
            this.lblDBConn.TabIndex = 1;
            this.lblDBConn.Text = "Database Status";
            // 
            // lblDateTime
            // 
            this.lblDateTime.AutoSize = true;
            this.lblDateTime.Location = new System.Drawing.Point(4, 4);
            this.lblDateTime.Name = "lblDateTime";
            this.lblDateTime.Size = new System.Drawing.Size(77, 13);
            this.lblDateTime.TabIndex = 0;
            this.lblDateTime.Text = "Date and Time";
            // 
            // pnlGeneralInfo
            // 
            this.pnlGeneralInfo.Controls.Add(this.lblLastCreated);
            this.pnlGeneralInfo.Controls.Add(this.lblCoachInfo);
            this.pnlGeneralInfo.Controls.Add(this.lblTeamsInfo);
            this.pnlGeneralInfo.Location = new System.Drawing.Point(17, 56);
            this.pnlGeneralInfo.Name = "pnlGeneralInfo";
            this.pnlGeneralInfo.Size = new System.Drawing.Size(115, 56);
            this.pnlGeneralInfo.TabIndex = 2;
            // 
            // lblLastCreated
            // 
            this.lblLastCreated.AutoSize = true;
            this.lblLastCreated.Location = new System.Drawing.Point(7, 38);
            this.lblLastCreated.Name = "lblLastCreated";
            this.lblLastCreated.Size = new System.Drawing.Size(97, 13);
            this.lblLastCreated.TabIndex = 2;
            this.lblLastCreated.Text = "Last Team Created";
            // 
            // lblCoachInfo
            // 
            this.lblCoachInfo.AutoSize = true;
            this.lblCoachInfo.Location = new System.Drawing.Point(7, 21);
            this.lblCoachInfo.Name = "lblCoachInfo";
            this.lblCoachInfo.Size = new System.Drawing.Size(38, 13);
            this.lblCoachInfo.TabIndex = 1;
            this.lblCoachInfo.Text = "Coach";
            // 
            // lblTeamsInfo
            // 
            this.lblTeamsInfo.AutoSize = true;
            this.lblTeamsInfo.Location = new System.Drawing.Point(4, 4);
            this.lblTeamsInfo.Name = "lblTeamsInfo";
            this.lblTeamsInfo.Size = new System.Drawing.Size(39, 13);
            this.lblTeamsInfo.TabIndex = 0;
            this.lblTeamsInfo.Text = "Teams";
            // 
            // tabTeamsMain
            // 
            this.tabTeamsMain.Controls.Add(this.tabNewTeam);
            this.tabTeamsMain.Controls.Add(this.tabTeamsSearch);
            this.tabTeamsMain.Controls.Add(this.tabAboutTeams);
            this.tabTeamsMain.Location = new System.Drawing.Point(17, 137);
            this.tabTeamsMain.Name = "tabTeamsMain";
            this.tabTeamsMain.SelectedIndex = 0;
            this.tabTeamsMain.Size = new System.Drawing.Size(350, 250);
            this.tabTeamsMain.TabIndex = 3;
            // 
            // tabNewTeam
            // 
            this.tabNewTeam.Controls.Add(this.lblNewTeamError);
            this.tabNewTeam.Controls.Add(this.lblNewTeamInfo);
            this.tabNewTeam.Controls.Add(this.lblDirectorNewTeam);
            this.tabNewTeam.Controls.Add(this.lblCoachNameNewTeam);
            this.tabNewTeam.Controls.Add(this.lblEmailNewTeam);
            this.tabNewTeam.Controls.Add(this.lblContactNewTeam);
            this.tabNewTeam.Controls.Add(this.lblCityNewTeam);
            this.tabNewTeam.Controls.Add(this.lblZipNewTeam);
            this.tabNewTeam.Controls.Add(this.lblAddress2NewTeam);
            this.tabNewTeam.Controls.Add(this.lblAddressNewTeam);
            this.tabNewTeam.Controls.Add(this.lblTeamName);
            this.tabNewTeam.Controls.Add(this.btnCancelNewTeam);
            this.tabNewTeam.Controls.Add(this.btnAddTeam);
            this.tabNewTeam.Controls.Add(this.txtTeamNewEmail);
            this.tabNewTeam.Controls.Add(this.txtTeamNewPhone);
            this.tabNewTeam.Controls.Add(this.txtTeamNewCity);
            this.tabNewTeam.Controls.Add(this.txtTeamNewZip);
            this.tabNewTeam.Controls.Add(this.txtTeamNewAddress2);
            this.tabNewTeam.Controls.Add(this.txtTeamNewAddress);
            this.tabNewTeam.Controls.Add(this.txtTeamNewDirector);
            this.tabNewTeam.Controls.Add(this.txtTeamNewCoach);
            this.tabNewTeam.Controls.Add(this.txtTeamNewName);
            this.tabNewTeam.Location = new System.Drawing.Point(4, 22);
            this.tabNewTeam.Name = "tabNewTeam";
            this.tabNewTeam.Padding = new System.Windows.Forms.Padding(3);
            this.tabNewTeam.Size = new System.Drawing.Size(342, 224);
            this.tabNewTeam.TabIndex = 0;
            this.tabNewTeam.Text = "New";
            this.tabNewTeam.UseVisualStyleBackColor = true;
            // 
            // lblEmailNewTeam
            // 
            this.lblEmailNewTeam.AutoSize = true;
            this.lblEmailNewTeam.Location = new System.Drawing.Point(11, 110);
            this.lblEmailNewTeam.Name = "lblEmailNewTeam";
            this.lblEmailNewTeam.Size = new System.Drawing.Size(32, 13);
            this.lblEmailNewTeam.TabIndex = 17;
            this.lblEmailNewTeam.Text = "Email";
            // 
            // lblContactNewTeam
            // 
            this.lblContactNewTeam.AutoSize = true;
            this.lblContactNewTeam.Location = new System.Drawing.Point(220, 64);
            this.lblContactNewTeam.Name = "lblContactNewTeam";
            this.lblContactNewTeam.Size = new System.Drawing.Size(76, 13);
            this.lblContactNewTeam.TabIndex = 16;
            this.lblContactNewTeam.Text = "Phone number";
            // 
            // lblCityNewTeam
            // 
            this.lblCityNewTeam.AutoSize = true;
            this.lblCityNewTeam.Location = new System.Drawing.Point(114, 64);
            this.lblCityNewTeam.Name = "lblCityNewTeam";
            this.lblCityNewTeam.Size = new System.Drawing.Size(24, 13);
            this.lblCityNewTeam.TabIndex = 15;
            this.lblCityNewTeam.Text = "City";
            // 
            // lblZipNewTeam
            // 
            this.lblZipNewTeam.AutoSize = true;
            this.lblZipNewTeam.Location = new System.Drawing.Point(11, 64);
            this.lblZipNewTeam.Name = "lblZipNewTeam";
            this.lblZipNewTeam.Size = new System.Drawing.Size(64, 13);
            this.lblZipNewTeam.TabIndex = 14;
            this.lblZipNewTeam.Text = "Postal Code";
            // 
            // lblAddress2NewTeam
            // 
            this.lblAddress2NewTeam.AutoSize = true;
            this.lblAddress2NewTeam.Location = new System.Drawing.Point(220, 16);
            this.lblAddress2NewTeam.Name = "lblAddress2NewTeam";
            this.lblAddress2NewTeam.Size = new System.Drawing.Size(54, 13);
            this.lblAddress2NewTeam.TabIndex = 13;
            this.lblAddress2NewTeam.Text = "Address 2";
            // 
            // lblAddressNewTeam
            // 
            this.lblAddressNewTeam.AutoSize = true;
            this.lblAddressNewTeam.Location = new System.Drawing.Point(114, 16);
            this.lblAddressNewTeam.Name = "lblAddressNewTeam";
            this.lblAddressNewTeam.Size = new System.Drawing.Size(45, 13);
            this.lblAddressNewTeam.TabIndex = 12;
            this.lblAddressNewTeam.Text = "Address";
            // 
            // lblTeamName
            // 
            this.lblTeamName.AutoSize = true;
            this.lblTeamName.Location = new System.Drawing.Point(11, 16);
            this.lblTeamName.Name = "lblTeamName";
            this.lblTeamName.Size = new System.Drawing.Size(35, 13);
            this.lblTeamName.TabIndex = 11;
            this.lblTeamName.Text = "Name";
            // 
            // btnCancelNewTeam
            // 
            this.btnCancelNewTeam.Location = new System.Drawing.Point(237, 195);
            this.btnCancelNewTeam.Name = "btnCancelNewTeam";
            this.btnCancelNewTeam.Size = new System.Drawing.Size(100, 23);
            this.btnCancelNewTeam.TabIndex = 10;
            this.btnCancelNewTeam.Text = "Cancel";
            this.btnCancelNewTeam.UseVisualStyleBackColor = true;
            // 
            // btnAddTeam
            // 
            this.btnAddTeam.Location = new System.Drawing.Point(131, 195);
            this.btnAddTeam.Name = "btnAddTeam";
            this.btnAddTeam.Size = new System.Drawing.Size(100, 23);
            this.btnAddTeam.TabIndex = 9;
            this.btnAddTeam.Text = "Create Team";
            this.btnAddTeam.UseVisualStyleBackColor = true;
            this.btnAddTeam.Click += new System.EventHandler(this.BtnAddTeam_Click);
            // 
            // txtTeamNewEmail
            // 
            this.txtTeamNewEmail.Location = new System.Drawing.Point(11, 126);
            this.txtTeamNewEmail.Name = "txtTeamNewEmail";
            this.txtTeamNewEmail.Size = new System.Drawing.Size(100, 20);
            this.txtTeamNewEmail.TabIndex = 6;
            // 
            // txtTeamNewPhone
            // 
            this.txtTeamNewPhone.Location = new System.Drawing.Point(223, 80);
            this.txtTeamNewPhone.Name = "txtTeamNewPhone";
            this.txtTeamNewPhone.Size = new System.Drawing.Size(100, 20);
            this.txtTeamNewPhone.TabIndex = 5;
            // 
            // txtTeamNewCity
            // 
            this.txtTeamNewCity.Location = new System.Drawing.Point(117, 80);
            this.txtTeamNewCity.Name = "txtTeamNewCity";
            this.txtTeamNewCity.Size = new System.Drawing.Size(100, 20);
            this.txtTeamNewCity.TabIndex = 4;
            // 
            // txtTeamNewZip
            // 
            this.txtTeamNewZip.Location = new System.Drawing.Point(11, 80);
            this.txtTeamNewZip.Name = "txtTeamNewZip";
            this.txtTeamNewZip.Size = new System.Drawing.Size(100, 20);
            this.txtTeamNewZip.TabIndex = 3;
            // 
            // txtTeamNewAddress2
            // 
            this.txtTeamNewAddress2.Location = new System.Drawing.Point(223, 35);
            this.txtTeamNewAddress2.Name = "txtTeamNewAddress2";
            this.txtTeamNewAddress2.Size = new System.Drawing.Size(100, 20);
            this.txtTeamNewAddress2.TabIndex = 2;
            // 
            // txtTeamNewAddress
            // 
            this.txtTeamNewAddress.Location = new System.Drawing.Point(117, 35);
            this.txtTeamNewAddress.Name = "txtTeamNewAddress";
            this.txtTeamNewAddress.Size = new System.Drawing.Size(100, 20);
            this.txtTeamNewAddress.TabIndex = 1;
            // 
            // txtTeamNewDirector
            // 
            this.txtTeamNewDirector.Location = new System.Drawing.Point(223, 126);
            this.txtTeamNewDirector.Name = "txtTeamNewDirector";
            this.txtTeamNewDirector.Size = new System.Drawing.Size(100, 20);
            this.txtTeamNewDirector.TabIndex = 8;
            // 
            // txtTeamNewCoach
            // 
            this.txtTeamNewCoach.Location = new System.Drawing.Point(117, 126);
            this.txtTeamNewCoach.Name = "txtTeamNewCoach";
            this.txtTeamNewCoach.Size = new System.Drawing.Size(100, 20);
            this.txtTeamNewCoach.TabIndex = 7;
            // 
            // txtTeamNewName
            // 
            this.txtTeamNewName.Location = new System.Drawing.Point(11, 35);
            this.txtTeamNewName.Name = "txtTeamNewName";
            this.txtTeamNewName.Size = new System.Drawing.Size(100, 20);
            this.txtTeamNewName.TabIndex = 0;
            // 
            // tabTeamsSearch
            // 
            this.tabTeamsSearch.Controls.Add(this.btnSearchExport);
            this.tabTeamsSearch.Controls.Add(this.btnSearchClear);
            this.tabTeamsSearch.Controls.Add(this.btnSearch);
            this.tabTeamsSearch.Controls.Add(this.radioAllDirector);
            this.tabTeamsSearch.Controls.Add(this.radioAllCoach);
            this.tabTeamsSearch.Controls.Add(this.radioAllTeams);
            this.tabTeamsSearch.Controls.Add(this.label1);
            this.tabTeamsSearch.Controls.Add(this.label2);
            this.tabTeamsSearch.Controls.Add(this.label3);
            this.tabTeamsSearch.Controls.Add(this.label4);
            this.tabTeamsSearch.Controls.Add(this.label5);
            this.tabTeamsSearch.Controls.Add(this.label6);
            this.tabTeamsSearch.Controls.Add(this.label7);
            this.tabTeamsSearch.Controls.Add(this.label8);
            this.tabTeamsSearch.Controls.Add(this.label9);
            this.tabTeamsSearch.Controls.Add(this.txtSearchEmail);
            this.tabTeamsSearch.Controls.Add(this.txtSearchPhone);
            this.tabTeamsSearch.Controls.Add(this.txtSearchCity);
            this.tabTeamsSearch.Controls.Add(this.txtSearchZip);
            this.tabTeamsSearch.Controls.Add(this.txtSearchAddress2);
            this.tabTeamsSearch.Controls.Add(this.txtSearchAddress);
            this.tabTeamsSearch.Controls.Add(this.txtSearchDirector);
            this.tabTeamsSearch.Controls.Add(this.txtSearchCoach);
            this.tabTeamsSearch.Controls.Add(this.txtSearchName);
            this.tabTeamsSearch.Location = new System.Drawing.Point(4, 22);
            this.tabTeamsSearch.Name = "tabTeamsSearch";
            this.tabTeamsSearch.Padding = new System.Windows.Forms.Padding(3);
            this.tabTeamsSearch.Size = new System.Drawing.Size(342, 224);
            this.tabTeamsSearch.TabIndex = 1;
            this.tabTeamsSearch.Text = "Search";
            this.tabTeamsSearch.UseVisualStyleBackColor = true;
            // 
            // tabAboutTeams
            // 
            this.tabAboutTeams.Location = new System.Drawing.Point(4, 22);
            this.tabAboutTeams.Name = "tabAboutTeams";
            this.tabAboutTeams.Padding = new System.Windows.Forms.Padding(3);
            this.tabAboutTeams.Size = new System.Drawing.Size(374, 224);
            this.tabAboutTeams.TabIndex = 3;
            this.tabAboutTeams.Text = "About TMS";
            this.tabAboutTeams.UseVisualStyleBackColor = true;
            // 
            // lblCoachNameNewTeam
            // 
            this.lblCoachNameNewTeam.AutoSize = true;
            this.lblCoachNameNewTeam.Location = new System.Drawing.Point(114, 110);
            this.lblCoachNameNewTeam.Name = "lblCoachNameNewTeam";
            this.lblCoachNameNewTeam.Size = new System.Drawing.Size(38, 13);
            this.lblCoachNameNewTeam.TabIndex = 18;
            this.lblCoachNameNewTeam.Text = "Coach";
            // 
            // lblDirectorNewTeam
            // 
            this.lblDirectorNewTeam.AutoSize = true;
            this.lblDirectorNewTeam.Location = new System.Drawing.Point(220, 110);
            this.lblDirectorNewTeam.Name = "lblDirectorNewTeam";
            this.lblDirectorNewTeam.Size = new System.Drawing.Size(44, 13);
            this.lblDirectorNewTeam.TabIndex = 19;
            this.lblDirectorNewTeam.Text = "Director";
            // 
            // lblNewTeamInfo
            // 
            this.lblNewTeamInfo.AutoSize = true;
            this.lblNewTeamInfo.Font = new System.Drawing.Font("Microsoft JhengHei", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblNewTeamInfo.ForeColor = System.Drawing.Color.LimeGreen;
            this.lblNewTeamInfo.Location = new System.Drawing.Point(11, 163);
            this.lblNewTeamInfo.Name = "lblNewTeamInfo";
            this.lblNewTeamInfo.Size = new System.Drawing.Size(46, 16);
            this.lblNewTeamInfo.TabIndex = 20;
            this.lblNewTeamInfo.Text = "lblInfo";
            this.lblNewTeamInfo.Visible = false;
            // 
            // lblNewTeamError
            // 
            this.lblNewTeamError.AutoSize = true;
            this.lblNewTeamError.Font = new System.Drawing.Font("Microsoft JhengHei", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblNewTeamError.ForeColor = System.Drawing.Color.Red;
            this.lblNewTeamError.Location = new System.Drawing.Point(11, 186);
            this.lblNewTeamError.Name = "lblNewTeamError";
            this.lblNewTeamError.Size = new System.Drawing.Size(52, 16);
            this.lblNewTeamError.TabIndex = 21;
            this.lblNewTeamError.Text = "lblError";
            this.lblNewTeamError.Visible = false;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(219, 101);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(44, 13);
            this.label1.TabIndex = 37;
            this.label1.Text = "Director";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(113, 101);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(38, 13);
            this.label2.TabIndex = 36;
            this.label2.Text = "Coach";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(10, 101);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(32, 13);
            this.label3.TabIndex = 35;
            this.label3.Text = "Email";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(219, 55);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(76, 13);
            this.label4.TabIndex = 34;
            this.label4.Text = "Phone number";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(113, 55);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(24, 13);
            this.label5.TabIndex = 33;
            this.label5.Text = "City";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(10, 55);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(64, 13);
            this.label6.TabIndex = 32;
            this.label6.Text = "Postal Code";
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Location = new System.Drawing.Point(219, 7);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(54, 13);
            this.label7.TabIndex = 31;
            this.label7.Text = "Address 2";
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Location = new System.Drawing.Point(113, 7);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(45, 13);
            this.label8.TabIndex = 30;
            this.label8.Text = "Address";
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Location = new System.Drawing.Point(10, 7);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(35, 13);
            this.label9.TabIndex = 29;
            this.label9.Text = "Name";
            // 
            // txtSearchEmail
            // 
            this.txtSearchEmail.Location = new System.Drawing.Point(10, 117);
            this.txtSearchEmail.Name = "txtSearchEmail";
            this.txtSearchEmail.Size = new System.Drawing.Size(100, 20);
            this.txtSearchEmail.TabIndex = 26;
            // 
            // txtSearchPhone
            // 
            this.txtSearchPhone.Location = new System.Drawing.Point(222, 71);
            this.txtSearchPhone.Name = "txtSearchPhone";
            this.txtSearchPhone.Size = new System.Drawing.Size(100, 20);
            this.txtSearchPhone.TabIndex = 25;
            // 
            // txtSearchCity
            // 
            this.txtSearchCity.Location = new System.Drawing.Point(116, 71);
            this.txtSearchCity.Name = "txtSearchCity";
            this.txtSearchCity.Size = new System.Drawing.Size(100, 20);
            this.txtSearchCity.TabIndex = 24;
            // 
            // txtSearchZip
            // 
            this.txtSearchZip.Location = new System.Drawing.Point(10, 71);
            this.txtSearchZip.Name = "txtSearchZip";
            this.txtSearchZip.Size = new System.Drawing.Size(100, 20);
            this.txtSearchZip.TabIndex = 23;
            // 
            // txtSearchAddress2
            // 
            this.txtSearchAddress2.Location = new System.Drawing.Point(222, 26);
            this.txtSearchAddress2.Name = "txtSearchAddress2";
            this.txtSearchAddress2.Size = new System.Drawing.Size(100, 20);
            this.txtSearchAddress2.TabIndex = 22;
            // 
            // txtSearchAddress
            // 
            this.txtSearchAddress.Location = new System.Drawing.Point(116, 26);
            this.txtSearchAddress.Name = "txtSearchAddress";
            this.txtSearchAddress.Size = new System.Drawing.Size(100, 20);
            this.txtSearchAddress.TabIndex = 21;
            // 
            // txtSearchDirector
            // 
            this.txtSearchDirector.Location = new System.Drawing.Point(222, 117);
            this.txtSearchDirector.Name = "txtSearchDirector";
            this.txtSearchDirector.Size = new System.Drawing.Size(100, 20);
            this.txtSearchDirector.TabIndex = 28;
            // 
            // txtSearchCoach
            // 
            this.txtSearchCoach.Location = new System.Drawing.Point(116, 117);
            this.txtSearchCoach.Name = "txtSearchCoach";
            this.txtSearchCoach.Size = new System.Drawing.Size(100, 20);
            this.txtSearchCoach.TabIndex = 27;
            // 
            // txtSearchName
            // 
            this.txtSearchName.Location = new System.Drawing.Point(10, 26);
            this.txtSearchName.Name = "txtSearchName";
            this.txtSearchName.Size = new System.Drawing.Size(100, 20);
            this.txtSearchName.TabIndex = 20;
            // 
            // radioAllTeams
            // 
            this.radioAllTeams.AutoSize = true;
            this.radioAllTeams.Location = new System.Drawing.Point(10, 159);
            this.radioAllTeams.Name = "radioAllTeams";
            this.radioAllTeams.Size = new System.Drawing.Size(71, 17);
            this.radioAllTeams.TabIndex = 38;
            this.radioAllTeams.TabStop = true;
            this.radioAllTeams.Text = "All Teams";
            this.radioAllTeams.UseVisualStyleBackColor = true;
            // 
            // radioAllCoach
            // 
            this.radioAllCoach.AutoSize = true;
            this.radioAllCoach.Location = new System.Drawing.Point(10, 180);
            this.radioAllCoach.Name = "radioAllCoach";
            this.radioAllCoach.Size = new System.Drawing.Size(70, 17);
            this.radioAllCoach.TabIndex = 39;
            this.radioAllCoach.TabStop = true;
            this.radioAllCoach.Text = "All Coach";
            this.radioAllCoach.UseVisualStyleBackColor = true;
            // 
            // radioAllDirector
            // 
            this.radioAllDirector.AutoSize = true;
            this.radioAllDirector.Location = new System.Drawing.Point(10, 201);
            this.radioAllDirector.Name = "radioAllDirector";
            this.radioAllDirector.Size = new System.Drawing.Size(76, 17);
            this.radioAllDirector.TabIndex = 40;
            this.radioAllDirector.TabStop = true;
            this.radioAllDirector.Text = "All Director";
            this.radioAllDirector.UseVisualStyleBackColor = true;
            // 
            // btnSearch
            // 
            this.btnSearch.Location = new System.Drawing.Point(98, 159);
            this.btnSearch.Name = "btnSearch";
            this.btnSearch.Size = new System.Drawing.Size(75, 23);
            this.btnSearch.TabIndex = 41;
            this.btnSearch.Text = "Search";
            this.btnSearch.UseVisualStyleBackColor = true;
            this.btnSearch.Click += new System.EventHandler(this.BtnSearch_Click);
            // 
            // btnSearchClear
            // 
            this.btnSearchClear.Location = new System.Drawing.Point(180, 159);
            this.btnSearchClear.Name = "btnSearchClear";
            this.btnSearchClear.Size = new System.Drawing.Size(75, 23);
            this.btnSearchClear.TabIndex = 42;
            this.btnSearchClear.Text = "Clear";
            this.btnSearchClear.UseVisualStyleBackColor = true;
            this.btnSearchClear.Click += new System.EventHandler(this.BtnSearchClear_Click);
            // 
            // pnlReport
            // 
            this.pnlReport.Controls.Add(this.btnReportEdit);
            this.pnlReport.Controls.Add(this.lblReportID);
            this.pnlReport.Controls.Add(this.lblReportTextID);
            this.pnlReport.Controls.Add(this.btnReportDelete);
            this.pnlReport.Controls.Add(this.btnReportUpdate);
            this.pnlReport.Controls.Add(this.label10);
            this.pnlReport.Controls.Add(this.label11);
            this.pnlReport.Controls.Add(this.label12);
            this.pnlReport.Controls.Add(this.label13);
            this.pnlReport.Controls.Add(this.label14);
            this.pnlReport.Controls.Add(this.label15);
            this.pnlReport.Controls.Add(this.label16);
            this.pnlReport.Controls.Add(this.label17);
            this.pnlReport.Controls.Add(this.label18);
            this.pnlReport.Controls.Add(this.txtReportEmail);
            this.pnlReport.Controls.Add(this.txtReportPhoneNumber);
            this.pnlReport.Controls.Add(this.txtReportCity);
            this.pnlReport.Controls.Add(this.txtReportZip);
            this.pnlReport.Controls.Add(this.txtReportAddress2);
            this.pnlReport.Controls.Add(this.txtReportAddress);
            this.pnlReport.Controls.Add(this.txtReportDirector);
            this.pnlReport.Controls.Add(this.txtReportCoach);
            this.pnlReport.Controls.Add(this.txtReportName);
            this.pnlReport.Location = new System.Drawing.Point(391, 166);
            this.pnlReport.Name = "pnlReport";
            this.pnlReport.Size = new System.Drawing.Size(346, 195);
            this.pnlReport.TabIndex = 5;
            this.pnlReport.Visible = false;
            // 
            // dgvSearch
            // 
            this.dgvSearch.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgvSearch.Location = new System.Drawing.Point(17, 411);
            this.dgvSearch.Name = "dgvSearch";
            this.dgvSearch.Size = new System.Drawing.Size(720, 228);
            this.dgvSearch.TabIndex = 6;
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Location = new System.Drawing.Point(222, 103);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(44, 13);
            this.label10.TabIndex = 55;
            this.label10.Text = "Director";
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.Location = new System.Drawing.Point(116, 103);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(38, 13);
            this.label11.TabIndex = 54;
            this.label11.Text = "Coach";
            // 
            // label12
            // 
            this.label12.AutoSize = true;
            this.label12.Location = new System.Drawing.Point(13, 103);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(32, 13);
            this.label12.TabIndex = 53;
            this.label12.Text = "Email";
            // 
            // label13
            // 
            this.label13.AutoSize = true;
            this.label13.Location = new System.Drawing.Point(222, 57);
            this.label13.Name = "label13";
            this.label13.Size = new System.Drawing.Size(76, 13);
            this.label13.TabIndex = 52;
            this.label13.Text = "Phone number";
            // 
            // label14
            // 
            this.label14.AutoSize = true;
            this.label14.Location = new System.Drawing.Point(116, 57);
            this.label14.Name = "label14";
            this.label14.Size = new System.Drawing.Size(24, 13);
            this.label14.TabIndex = 51;
            this.label14.Text = "City";
            // 
            // label15
            // 
            this.label15.AutoSize = true;
            this.label15.Location = new System.Drawing.Point(13, 57);
            this.label15.Name = "label15";
            this.label15.Size = new System.Drawing.Size(64, 13);
            this.label15.TabIndex = 50;
            this.label15.Text = "Postal Code";
            // 
            // label16
            // 
            this.label16.AutoSize = true;
            this.label16.Location = new System.Drawing.Point(222, 9);
            this.label16.Name = "label16";
            this.label16.Size = new System.Drawing.Size(54, 13);
            this.label16.TabIndex = 49;
            this.label16.Text = "Address 2";
            // 
            // label17
            // 
            this.label17.AutoSize = true;
            this.label17.Location = new System.Drawing.Point(116, 9);
            this.label17.Name = "label17";
            this.label17.Size = new System.Drawing.Size(45, 13);
            this.label17.TabIndex = 48;
            this.label17.Text = "Address";
            // 
            // label18
            // 
            this.label18.AutoSize = true;
            this.label18.Location = new System.Drawing.Point(13, 9);
            this.label18.Name = "label18";
            this.label18.Size = new System.Drawing.Size(35, 13);
            this.label18.TabIndex = 47;
            this.label18.Text = "Name";
            // 
            // txtReportEmail
            // 
            this.txtReportEmail.Location = new System.Drawing.Point(13, 119);
            this.txtReportEmail.Name = "txtReportEmail";
            this.txtReportEmail.ReadOnly = true;
            this.txtReportEmail.Size = new System.Drawing.Size(100, 20);
            this.txtReportEmail.TabIndex = 44;
            // 
            // txtReportPhoneNumber
            // 
            this.txtReportPhoneNumber.Location = new System.Drawing.Point(225, 73);
            this.txtReportPhoneNumber.Name = "txtReportPhoneNumber";
            this.txtReportPhoneNumber.ReadOnly = true;
            this.txtReportPhoneNumber.Size = new System.Drawing.Size(100, 20);
            this.txtReportPhoneNumber.TabIndex = 43;
            // 
            // txtReportCity
            // 
            this.txtReportCity.Location = new System.Drawing.Point(119, 73);
            this.txtReportCity.Name = "txtReportCity";
            this.txtReportCity.ReadOnly = true;
            this.txtReportCity.Size = new System.Drawing.Size(100, 20);
            this.txtReportCity.TabIndex = 42;
            // 
            // txtReportZip
            // 
            this.txtReportZip.Location = new System.Drawing.Point(13, 73);
            this.txtReportZip.Name = "txtReportZip";
            this.txtReportZip.ReadOnly = true;
            this.txtReportZip.Size = new System.Drawing.Size(100, 20);
            this.txtReportZip.TabIndex = 41;
            // 
            // txtReportAddress2
            // 
            this.txtReportAddress2.Location = new System.Drawing.Point(225, 28);
            this.txtReportAddress2.Name = "txtReportAddress2";
            this.txtReportAddress2.ReadOnly = true;
            this.txtReportAddress2.Size = new System.Drawing.Size(100, 20);
            this.txtReportAddress2.TabIndex = 40;
            // 
            // txtReportAddress
            // 
            this.txtReportAddress.Location = new System.Drawing.Point(119, 28);
            this.txtReportAddress.Name = "txtReportAddress";
            this.txtReportAddress.ReadOnly = true;
            this.txtReportAddress.Size = new System.Drawing.Size(100, 20);
            this.txtReportAddress.TabIndex = 39;
            // 
            // txtReportDirector
            // 
            this.txtReportDirector.Location = new System.Drawing.Point(225, 119);
            this.txtReportDirector.Name = "txtReportDirector";
            this.txtReportDirector.ReadOnly = true;
            this.txtReportDirector.Size = new System.Drawing.Size(100, 20);
            this.txtReportDirector.TabIndex = 46;
            // 
            // txtReportCoach
            // 
            this.txtReportCoach.Location = new System.Drawing.Point(119, 119);
            this.txtReportCoach.Name = "txtReportCoach";
            this.txtReportCoach.ReadOnly = true;
            this.txtReportCoach.Size = new System.Drawing.Size(100, 20);
            this.txtReportCoach.TabIndex = 45;
            // 
            // txtReportName
            // 
            this.txtReportName.Location = new System.Drawing.Point(13, 28);
            this.txtReportName.Name = "txtReportName";
            this.txtReportName.ReadOnly = true;
            this.txtReportName.Size = new System.Drawing.Size(100, 20);
            this.txtReportName.TabIndex = 38;
            // 
            // btnReportUpdate
            // 
            this.btnReportUpdate.Enabled = false;
            this.btnReportUpdate.Location = new System.Drawing.Point(168, 156);
            this.btnReportUpdate.Name = "btnReportUpdate";
            this.btnReportUpdate.Size = new System.Drawing.Size(75, 23);
            this.btnReportUpdate.TabIndex = 56;
            this.btnReportUpdate.Text = "Update";
            this.btnReportUpdate.UseVisualStyleBackColor = true;
            this.btnReportUpdate.Click += new System.EventHandler(this.BtnReportUpdate_Click);
            // 
            // btnReportDelete
            // 
            this.btnReportDelete.Enabled = false;
            this.btnReportDelete.Location = new System.Drawing.Point(249, 156);
            this.btnReportDelete.Name = "btnReportDelete";
            this.btnReportDelete.Size = new System.Drawing.Size(75, 23);
            this.btnReportDelete.TabIndex = 57;
            this.btnReportDelete.Text = "Delete";
            this.btnReportDelete.UseVisualStyleBackColor = true;
            this.btnReportDelete.Click += new System.EventHandler(this.BtnReportDelete_Click);
            // 
            // lblReportTextID
            // 
            this.lblReportTextID.AutoSize = true;
            this.lblReportTextID.Location = new System.Drawing.Point(250, 181);
            this.lblReportTextID.Name = "lblReportTextID";
            this.lblReportTextID.Size = new System.Drawing.Size(48, 13);
            this.lblReportTextID.TabIndex = 58;
            this.lblReportTextID.Text = "Team ID";
            this.lblReportTextID.Visible = false;
            // 
            // lblReportID
            // 
            this.lblReportID.AutoSize = true;
            this.lblReportID.Location = new System.Drawing.Point(304, 181);
            this.lblReportID.Name = "lblReportID";
            this.lblReportID.Size = new System.Drawing.Size(28, 13);
            this.lblReportID.TabIndex = 59;
            this.lblReportID.Text = "###";
            this.lblReportID.Visible = false;
            // 
            // btnReportEdit
            // 
            this.btnReportEdit.Location = new System.Drawing.Point(86, 156);
            this.btnReportEdit.Name = "btnReportEdit";
            this.btnReportEdit.Size = new System.Drawing.Size(75, 23);
            this.btnReportEdit.TabIndex = 61;
            this.btnReportEdit.Text = "Edit Team";
            this.btnReportEdit.UseVisualStyleBackColor = true;
            this.btnReportEdit.Click += new System.EventHandler(this.BtnReportEdit_Click);
            // 
            // btnSearchExport
            // 
            this.btnSearchExport.Location = new System.Drawing.Point(261, 159);
            this.btnSearchExport.Name = "btnSearchExport";
            this.btnSearchExport.Size = new System.Drawing.Size(75, 23);
            this.btnSearchExport.TabIndex = 43;
            this.btnSearchExport.Text = "Export";
            this.btnSearchExport.UseVisualStyleBackColor = true;
            this.btnSearchExport.Click += new System.EventHandler(this.BtnSearchExport_Click);
            // 
            // frmMain
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(752, 669);
            this.Controls.Add(this.dgvSearch);
            this.Controls.Add(this.pnlReport);
            this.Controls.Add(this.tabTeamsMain);
            this.Controls.Add(this.pnlGeneralInfo);
            this.Controls.Add(this.panel1);
            this.Controls.Add(this.lblMainInfo);
            this.Name = "frmMain";
            this.ShowIcon = false;
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "TMS v0.1";
            this.Load += new System.EventHandler(this.FrmMain_Load);
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            this.pnlGeneralInfo.ResumeLayout(false);
            this.pnlGeneralInfo.PerformLayout();
            this.tabTeamsMain.ResumeLayout(false);
            this.tabNewTeam.ResumeLayout(false);
            this.tabNewTeam.PerformLayout();
            this.tabTeamsSearch.ResumeLayout(false);
            this.tabTeamsSearch.PerformLayout();
            this.pnlReport.ResumeLayout(false);
            this.pnlReport.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgvSearch)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label lblMainInfo;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Label lblDBConn;
        private System.Windows.Forms.Label lblDateTime;
        private System.Windows.Forms.Panel pnlGeneralInfo;
        private System.Windows.Forms.Label lblLastCreated;
        private System.Windows.Forms.Label lblCoachInfo;
        private System.Windows.Forms.Label lblTeamsInfo;
        private System.Windows.Forms.TabControl tabTeamsMain;
        private System.Windows.Forms.TabPage tabNewTeam;
        private System.Windows.Forms.Label lblEmailNewTeam;
        private System.Windows.Forms.Label lblContactNewTeam;
        private System.Windows.Forms.Label lblCityNewTeam;
        private System.Windows.Forms.Label lblZipNewTeam;
        private System.Windows.Forms.Label lblAddress2NewTeam;
        private System.Windows.Forms.Label lblAddressNewTeam;
        private System.Windows.Forms.Label lblTeamName;
        private System.Windows.Forms.Button btnCancelNewTeam;
        private System.Windows.Forms.Button btnAddTeam;
        private System.Windows.Forms.TextBox txtTeamNewEmail;
        private System.Windows.Forms.TextBox txtTeamNewPhone;
        private System.Windows.Forms.TextBox txtTeamNewCity;
        private System.Windows.Forms.TextBox txtTeamNewZip;
        private System.Windows.Forms.TextBox txtTeamNewAddress2;
        private System.Windows.Forms.TextBox txtTeamNewAddress;
        private System.Windows.Forms.TextBox txtTeamNewDirector;
        private System.Windows.Forms.TextBox txtTeamNewCoach;
        private System.Windows.Forms.TextBox txtTeamNewName;
        private System.Windows.Forms.TabPage tabTeamsSearch;
        private System.Windows.Forms.TabPage tabAboutTeams;
        private System.Windows.Forms.Label lblDirectorNewTeam;
        private System.Windows.Forms.Label lblCoachNameNewTeam;
        private System.Windows.Forms.Label lblNewTeamError;
        private System.Windows.Forms.Label lblNewTeamInfo;
        private System.Windows.Forms.Button btnSearch;
        private System.Windows.Forms.RadioButton radioAllDirector;
        private System.Windows.Forms.RadioButton radioAllCoach;
        private System.Windows.Forms.RadioButton radioAllTeams;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.TextBox txtSearchEmail;
        private System.Windows.Forms.TextBox txtSearchPhone;
        private System.Windows.Forms.TextBox txtSearchCity;
        private System.Windows.Forms.TextBox txtSearchZip;
        private System.Windows.Forms.TextBox txtSearchAddress2;
        private System.Windows.Forms.TextBox txtSearchAddress;
        private System.Windows.Forms.TextBox txtSearchDirector;
        private System.Windows.Forms.TextBox txtSearchCoach;
        private System.Windows.Forms.TextBox txtSearchName;
        private System.Windows.Forms.Button btnSearchClear;
        private System.Windows.Forms.Panel pnlReport;
        private System.Windows.Forms.DataGridView dgvSearch;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.Label label13;
        private System.Windows.Forms.Label label14;
        private System.Windows.Forms.Label label15;
        private System.Windows.Forms.Label label16;
        private System.Windows.Forms.Label label17;
        private System.Windows.Forms.Label label18;
        private System.Windows.Forms.TextBox txtReportEmail;
        private System.Windows.Forms.TextBox txtReportPhoneNumber;
        private System.Windows.Forms.TextBox txtReportCity;
        private System.Windows.Forms.TextBox txtReportZip;
        private System.Windows.Forms.TextBox txtReportAddress2;
        private System.Windows.Forms.TextBox txtReportAddress;
        private System.Windows.Forms.TextBox txtReportDirector;
        private System.Windows.Forms.TextBox txtReportCoach;
        private System.Windows.Forms.TextBox txtReportName;
        private System.Windows.Forms.Label lblReportTextID;
        private System.Windows.Forms.Button btnReportDelete;
        private System.Windows.Forms.Button btnReportUpdate;
        private System.Windows.Forms.Label lblReportID;
        private System.Windows.Forms.Button btnReportEdit;
        private System.Windows.Forms.Button btnSearchExport;
    }
}

