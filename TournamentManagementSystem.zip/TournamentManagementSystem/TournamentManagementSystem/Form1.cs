﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;
using System.IO;

namespace TournamentManagementSystem
{
    public partial class frmMain : Form
    {

        string connStr = "Server=INSTRUCTORIT; Database=TournamentManager; User Id=ProfileUser; Password=ProfileUser2019";
        string createdBy = "Mauricio Lattke";
        int teamID = 0;

        public frmMain()
        {
            InitializeComponent();
            dgvSearch.DoubleClick += new EventHandler(dgvSearch_DoubleClick);

        }

        private void FrmMain_Load(object sender, EventArgs e)
        {
            using (SqlConnection conn = new SqlConnection(connStr))
            {
                conn.Open();
                string testConn = "SELECT * FROM Teams";
                SqlCommand cmd = new SqlCommand(testConn, conn);
                SqlDataReader reader = cmd.ExecuteReader();
                int total = 0;

                while (reader.Read())
                {
                    total++;
                }

                lblTeamsInfo.Text = String.Format("Teams {0}", total);
                lblDBConn.Text = String.Format("Database OK");
            }
        }

        private void AddTeam()
        {
            using (SqlConnection conn = new SqlConnection(connStr))
            {
                conn.Open();
                string addRecord = String.Format(
                    "INSERT INTO Teams (TeamName, AddressLine1, AddressLine2, PostCode, City, " +
                    "ContactNumber, EmailAddress, CoachName, DirectorName, Createdby) " +
                    "VALUES ('{0}', '{1}', '{2}', '{3}', '{4}', '{5}', '{6}', '{7}', '{8}', '{9}')",
                    txtTeamNewName.Text, txtTeamNewAddress.Text, txtTeamNewAddress2.Text, 
                    txtTeamNewZip.Text, txtTeamNewCity.Text, txtTeamNewPhone.Text, txtTeamNewEmail.Text,
                    txtTeamNewCoach.Text, txtTeamNewDirector.Text, createdBy);
                SqlCommand cmd = new SqlCommand(addRecord, conn);
                int rowsAffected = cmd.ExecuteNonQuery();

                lblNewTeamInfo.Visible = true;
                lblNewTeamError.Text = txtTeamNewName.Text + " Added into the database.";
            }
            
        }

        private void SearchTeam()
        {
            //lstSearchResult.Items.Clear();
            //using (SqlConnection conn = new SqlConnection(connStr))
            //{
            //    conn.Open();
            //    string SearchConn = String.Format("SELECT * FROM Teams WHERE " +
            //        " TeamName='{0}' OR AddressLine1='{1}' OR AddressLine2='{2}'" +
            //        "OR PostCode='{3}' OR City='{4}' OR ContactNumber='{5}' " +
            //        "OR EmailAddress='{6}' OR CoachName='{7}' OR DirectorName='{8}'",
            //        txtSearchName.Text, txtSearchAddress.Text, txtSearchAddress2.Text,
            //        txtSearchZip.Text, txtSearchCity.Text, txtSearchPhone.Text, txtSearchEmail.Text,
            //        txtSearchCoach.Text, txtSearchDirector.Text);
            //    SqlCommand cmd = new SqlCommand(SearchConn, conn);
            //    SqlDataReader reader = cmd.ExecuteReader();
            //    int rowsAffected = 0;

            //    while (reader.Read())
            //    {
            //        string fullName = reader["TeamName"] + " " + reader["AddressLine1"];
            //        lstSearchResult.Items.Add(fullName);
            //        rowsAffected++;
            //    }
            //    lblDBConn.Text = String.Format("{0} Records found.", rowsAffected);
            //}
        }

        private void SearchTeam2()
        {
            var select = String.Format("SELECT * FROM Teams WHERE " +
                    " TeamName='{0}' OR AddressLine1='{1}' OR AddressLine2='{2}'" +
                    "OR PostCode='{3}' OR City='{4}' OR ContactNumber='{5}' " +
                    "OR EmailAddress='{6}' OR CoachName='{7}' OR DirectorName='{8}'",
                    txtSearchName.Text, txtSearchAddress.Text, txtSearchAddress2.Text,
                    txtSearchZip.Text, txtSearchCity.Text, txtSearchPhone.Text, txtSearchEmail.Text,
                    txtSearchCoach.Text, txtSearchDirector.Text);
            var c = new SqlConnection(connStr);
            var dataAdapter = new SqlDataAdapter(select, c);

            var commandBuilder = new SqlCommandBuilder(dataAdapter);
            var ds = new DataSet();
            dataAdapter.Fill(ds);
            dgvSearch.ReadOnly = true;
            dgvSearch.DataSource = ds.Tables[0];
        }

        private void BtnAddTeam_Click(object sender, EventArgs e)
        {
            AddTeam();
        }

        private void BtnSearch_Click(object sender, EventArgs e)
        {
            SearchTeam2();            
        }        

        private void BtnSearchClear_Click(object sender, EventArgs e)
        {
            pnlReport.Visible = false;
           // dgvSearch.Rows.Clear();
        }

        private void dgvSearch_DoubleClick(object sender, EventArgs e)
        {
            pnlReport.Visible = true;

            var TeamName = dgvSearch.CurrentRow.Cells[1].Value;
            var Address = dgvSearch.CurrentRow.Cells[4].Value;
            var Address2 = dgvSearch.CurrentRow.Cells[5].Value;
            var PostalCode = dgvSearch.CurrentRow.Cells[6].Value;
            var City = dgvSearch.CurrentRow.Cells[8].Value;
            var PhoneNumber = dgvSearch.CurrentRow.Cells[9].Value;
            var Email = dgvSearch.CurrentRow.Cells[7].Value;
            var Coach = dgvSearch.CurrentRow.Cells[2].Value;
            var Director = dgvSearch.CurrentRow.Cells[3].Value;
            var ID = dgvSearch.CurrentRow.Cells[0].Value;

            txtReportName.Text = TeamName.ToString();
            txtReportAddress.Text = Address.ToString();
            txtReportAddress2.Text = Address2.ToString();
            txtReportZip.Text = PostalCode.ToString();
            txtReportCity.Text = City.ToString();
            txtReportPhoneNumber.Text = PhoneNumber.ToString();
            txtReportEmail.Text = Email.ToString();
            txtReportCoach.Text = Coach.ToString();
            txtReportDirector.Text = Director.ToString();
            lblReportID.Text = ID.ToString();

        }

        private void BtnReportDelete_Click(object sender, EventArgs e)
        {            
            using (SqlConnection conn = new SqlConnection(connStr))
            {
                conn.Open();
                string SearchConn = String.Format("DELETE FROM Teams WHERE TeamId = {0}",
                    lblReportID.Text);
                SqlCommand cmd = new SqlCommand(SearchConn, conn);
                SqlDataReader reader = cmd.ExecuteReader();                
            }
        }

        private void BtnReportEdit_Click(object sender, EventArgs e)
        {
            btnReportUpdate.Enabled = true;
            btnReportDelete.Enabled = true;

            txtReportName.ReadOnly = false;
            txtReportAddress.ReadOnly = false;
            txtReportAddress2.ReadOnly = false;
            txtReportZip.ReadOnly = false;
            txtReportCity.ReadOnly = false;
            txtReportPhoneNumber.ReadOnly = false;
            txtReportEmail.ReadOnly = false;
            txtReportCoach.ReadOnly = false;
            txtReportDirector.ReadOnly = false;
        }

        private void BtnReportUpdate_Click(object sender, EventArgs e)
        {
            using (SqlConnection conn = new SqlConnection(connStr))
            {
                conn.Open();
                string SearchConn = String.Format("UPDATE Teams " +
                    "SET TeamName = '{0}', AddressLine1 = '{1}', AddressLine2 = '{2}', " +
                    "PostCode = '{3}', City = '{4}', ContactNumber = '{5}', EmailAddress = '{6}', " +
                    "CoachName = '{7}', DirectorName = '{8}'" +
                    " WHERE TeamId = {9}; ",
                    txtReportName.Text, txtReportAddress.Text, txtReportAddress2.Text,
                    txtReportZip.Text, txtReportCity.Text, txtReportPhoneNumber.Text, txtReportEmail.Text,
                    txtReportCoach.Text, txtReportDirector.Text, lblReportID.Text);
                SqlCommand cmd = new SqlCommand(SearchConn, conn);
                SqlDataReader reader = cmd.ExecuteReader();
                int rowsAffected = 0;

                while (reader.Read())
                {                   
                    rowsAffected++;
                }
                lblDBConn.Text = String.Format("{0} Records updated.", rowsAffected);
            }
        }

        private void BtnSearchExport_Click(object sender, EventArgs e)
        {
            using (TextWriter tw = new StreamWriter(@"C:\report.txt"))
            {
                for (int i = 0; i < dgvSearch.Rows.Count - 1; i++)
                {
                    for (int j = 0; j < dgvSearch.Columns.Count; j++)
                    {
                        tw.Write($"{dgvSearch.Rows[i].Cells[j].Value.ToString()}");

                        if (j != dgvSearch.Columns.Count - 1)
                        {
                            tw.Write(",");
                        }
                    }
                    tw.WriteLine();
                }
            }
        }
    }
}
