﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Drawing;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Dashboard_WF
{
    public partial class GetWeather2 : UserControl
    {
        public GetWeather2()
        {
            InitializeComponent();
        }

        private string WeatherCity;
        private string WeatherTemp;
        private string WeatherMinMax;
        private string WeatherRealTemp;
        private Image WeatherPic;

        [Category("Weather Properties")]
        public string weatherCity
        {
            get { return WeatherCity; }
            set { WeatherCity = value; lblCity.Text = value; }
        }

        [Category("Weather Properties")]
        public string weatherTemp
        {
            get { return WeatherTemp; }
            set { WeatherTemp = value; lblCurrentTemp.Text = value; }
        }

        [Category("Weather Properties")]
        public string weatherMinMax
        {
            get { return WeatherMinMax; }
            set { WeatherMinMax = value; lblMinMaxTemp.Text = value; }
        }

        [Category("Weather Properties")]
        public string weatherRealTemp
        {
            get { return WeatherRealTemp; }
            set { WeatherRealTemp = value; lblRealTemp.Text = value; }
        }

        [Category("Weather Properties")]
        public Image weatherPic
        {
            get { return WeatherPic; }
            set { WeatherPic = value; imgWeather.Image = value; }
        }

    }
}
