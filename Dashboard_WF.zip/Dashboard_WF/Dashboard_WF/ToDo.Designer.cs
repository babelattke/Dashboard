﻿namespace Dashboard_WF
{
    partial class ToDo
    {
        /// <summary> 
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary> 
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Component Designer generated code

        /// <summary> 
        /// Required method for Designer support - do not modify 
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.lblDate = new System.Windows.Forms.Label();
            this.txtNote = new System.Windows.Forms.TextBox();
            this.lblCLose = new System.Windows.Forms.Label();
            this.picSaveNote = new System.Windows.Forms.PictureBox();
            this.picEditNote = new System.Windows.Forms.PictureBox();
            ((System.ComponentModel.ISupportInitialize)(this.picSaveNote)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.picEditNote)).BeginInit();
            this.SuspendLayout();
            // 
            // lblDate
            // 
            this.lblDate.AutoSize = true;
            this.lblDate.Font = new System.Drawing.Font("Microsoft JhengHei", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblDate.Location = new System.Drawing.Point(4, 134);
            this.lblDate.Name = "lblDate";
            this.lblDate.Size = new System.Drawing.Size(56, 15);
            this.lblDate.TabIndex = 0;
            this.lblDate.Text = "DateNow";
            // 
            // txtNote
            // 
            this.txtNote.BackColor = System.Drawing.Color.Gold;
            this.txtNote.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.txtNote.Font = new System.Drawing.Font("Microsoft JhengHei", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtNote.Location = new System.Drawing.Point(0, 3);
            this.txtNote.Multiline = true;
            this.txtNote.Name = "txtNote";
            this.txtNote.ReadOnly = true;
            this.txtNote.ScrollBars = System.Windows.Forms.ScrollBars.Vertical;
            this.txtNote.Size = new System.Drawing.Size(167, 128);
            this.txtNote.TabIndex = 1;
            // 
            // lblCLose
            // 
            this.lblCLose.AutoSize = true;
            this.lblCLose.Font = new System.Drawing.Font("Microsoft JhengHei", 6F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblCLose.Location = new System.Drawing.Point(133, 134);
            this.lblCLose.Name = "lblCLose";
            this.lblCLose.Size = new System.Drawing.Size(10, 10);
            this.lblCLose.TabIndex = 2;
            this.lblCLose.Text = "X";
            this.lblCLose.Click += new System.EventHandler(this.LblCLose_Click);
            // 
            // picSaveNote
            // 
            this.picSaveNote.Image = global::Dashboard_WF.Properties.Resources.ok;
            this.picSaveNote.Location = new System.Drawing.Point(113, 132);
            this.picSaveNote.Name = "picSaveNote";
            this.picSaveNote.Size = new System.Drawing.Size(14, 13);
            this.picSaveNote.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.picSaveNote.TabIndex = 5;
            this.picSaveNote.TabStop = false;
            this.picSaveNote.Visible = false;
            this.picSaveNote.Click += new System.EventHandler(this.PicSaveNote_Click);
            // 
            // picEditNote
            // 
            this.picEditNote.Image = global::Dashboard_WF.Properties.Resources.pencil;
            this.picEditNote.Location = new System.Drawing.Point(97, 132);
            this.picEditNote.Name = "picEditNote";
            this.picEditNote.Size = new System.Drawing.Size(14, 13);
            this.picEditNote.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.picEditNote.TabIndex = 6;
            this.picEditNote.TabStop = false;
            this.picEditNote.Click += new System.EventHandler(this.PicEditNote_Click);
            // 
            // ToDo
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.Gold;
            this.Controls.Add(this.picEditNote);
            this.Controls.Add(this.picSaveNote);
            this.Controls.Add(this.lblCLose);
            this.Controls.Add(this.txtNote);
            this.Controls.Add(this.lblDate);
            this.Name = "ToDo";
            ((System.ComponentModel.ISupportInitialize)(this.picSaveNote)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.picEditNote)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label lblDate;
        private System.Windows.Forms.TextBox txtNote;
        private System.Windows.Forms.Label lblCLose;
        private System.Windows.Forms.PictureBox picSaveNote;
        private System.Windows.Forms.PictureBox picEditNote;
    }
}
