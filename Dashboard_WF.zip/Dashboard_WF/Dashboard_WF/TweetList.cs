﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Drawing;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Dashboard_WF
{
    public partial class TweetList : UserControl
    {
        
        public TweetList()
        {
            InitializeComponent();
            lblTwitterAccount.ForeColor = ColorTranslator.FromHtml("#3282b8");
            lblTweetDateTime.ForeColor = ColorTranslator.FromHtml("#bbe1fa");
            txtTweetBody.BackColor = ColorTranslator.FromHtml("#1b262c");
            //txtTweetBody.ForeColor = ColorTranslator.FromHtml("#bbe1fa");
        }

        private string TwitterAccount;
        private string TweetBody;
        private string TweetDateTime;
        private Image ProfilePic;

        [Category("Tweet Properties")]
        public string twitterAccount
        {
            get { return TwitterAccount; }
            set { TwitterAccount = value; lblTwitterAccount.Text = value; }
        }

        [Category("Tweet Properties")]
        public string tweetBody
        {
            get { return TweetBody; }
            set { TweetBody = value; txtTweetBody.Text = value; }
        }

        [Category("Tweet Properties")]
        public string tweetDateTime
        {
            get { return TweetDateTime; }
            set { TweetDateTime = value; lblTweetDateTime.Text = value; }
        }

        [Category("Tweet Properties")]
        public Image profilePic
        {
            get { return ProfilePic; }
            set { ProfilePic = value; imgTweetProfile.Image = value; }
        }

        
    }
}
