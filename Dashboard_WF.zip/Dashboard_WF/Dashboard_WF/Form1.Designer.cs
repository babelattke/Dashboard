﻿namespace Dashboard_WF
{
    partial class frmMain
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.panel1 = new System.Windows.Forms.Panel();
            this.flowLayoutPanel1 = new System.Windows.Forms.FlowLayoutPanel();
            this.pnlWeather = new System.Windows.Forms.Panel();
            this.flowLayoutPanel2 = new System.Windows.Forms.FlowLayoutPanel();
            this.pnlRSSNews = new System.Windows.Forms.Panel();
            this.flowLayoutPanelRSS = new System.Windows.Forms.FlowLayoutPanel();
            this.pnlRefresh = new System.Windows.Forms.Panel();
            this.lblRSSLastUpdate = new System.Windows.Forms.Label();
            this.lblTwtLastUpdate = new System.Windows.Forms.Label();
            this.lblWeLastUpdate = new System.Windows.Forms.Label();
            this.txtHashTest = new System.Windows.Forms.TextBox();
            this.comboTweetLimit = new System.Windows.Forms.ComboBox();
            this.txtAddNote = new System.Windows.Forms.TextBox();
            this.pnlToDo = new System.Windows.Forms.Panel();
            this.flowLayoutPanelToDo = new System.Windows.Forms.FlowLayoutPanel();
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.tabSettings = new System.Windows.Forms.TabControl();
            this.tabWeatherSettings = new System.Windows.Forms.TabPage();
            this.lblCitySettings = new System.Windows.Forms.Label();
            this.cmbCitySettings = new System.Windows.Forms.ComboBox();
            this.radioButton2 = new System.Windows.Forms.RadioButton();
            this.radioButton1 = new System.Windows.Forms.RadioButton();
            this.tabTwitterSettings = new System.Windows.Forms.TabPage();
            this.tabRSSSettings = new System.Windows.Forms.TabPage();
            this.comboBox1 = new System.Windows.Forms.ComboBox();
            this.label3 = new System.Windows.Forms.Label();
            this.tabNotesSettings = new System.Windows.Forms.TabPage();
            this.radioButton6 = new System.Windows.Forms.RadioButton();
            this.radioButton5 = new System.Windows.Forms.RadioButton();
            this.radioButton4 = new System.Windows.Forms.RadioButton();
            this.radioButton3 = new System.Windows.Forms.RadioButton();
            this.label4 = new System.Windows.Forms.Label();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.btnRSSUpdate = new System.Windows.Forms.PictureBox();
            this.btnTwtUpdate = new System.Windows.Forms.PictureBox();
            this.btnWeUpdate = new System.Windows.Forms.PictureBox();
            this.lblAddNote = new System.Windows.Forms.Label();
            this.panel1.SuspendLayout();
            this.pnlWeather.SuspendLayout();
            this.pnlRSSNews.SuspendLayout();
            this.pnlRefresh.SuspendLayout();
            this.pnlToDo.SuspendLayout();
            this.tabSettings.SuspendLayout();
            this.tabWeatherSettings.SuspendLayout();
            this.tabTwitterSettings.SuspendLayout();
            this.tabRSSSettings.SuspendLayout();
            this.tabNotesSettings.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.btnRSSUpdate)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.btnTwtUpdate)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.btnWeUpdate)).BeginInit();
            this.SuspendLayout();
            // 
            // panel1
            // 
            this.panel1.Controls.Add(this.flowLayoutPanel1);
            this.panel1.Location = new System.Drawing.Point(13, 131);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(429, 370);
            this.panel1.TabIndex = 9;
            // 
            // flowLayoutPanel1
            // 
            this.flowLayoutPanel1.AutoScroll = true;
            this.flowLayoutPanel1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.flowLayoutPanel1.Location = new System.Drawing.Point(0, 0);
            this.flowLayoutPanel1.Name = "flowLayoutPanel1";
            this.flowLayoutPanel1.Size = new System.Drawing.Size(429, 370);
            this.flowLayoutPanel1.TabIndex = 0;
            // 
            // pnlWeather
            // 
            this.pnlWeather.Controls.Add(this.flowLayoutPanel2);
            this.pnlWeather.Location = new System.Drawing.Point(13, 12);
            this.pnlWeather.Name = "pnlWeather";
            this.pnlWeather.Size = new System.Drawing.Size(288, 113);
            this.pnlWeather.TabIndex = 10;
            // 
            // flowLayoutPanel2
            // 
            this.flowLayoutPanel2.Dock = System.Windows.Forms.DockStyle.Fill;
            this.flowLayoutPanel2.Location = new System.Drawing.Point(0, 0);
            this.flowLayoutPanel2.Name = "flowLayoutPanel2";
            this.flowLayoutPanel2.Size = new System.Drawing.Size(288, 113);
            this.flowLayoutPanel2.TabIndex = 0;
            // 
            // pnlRSSNews
            // 
            this.pnlRSSNews.Controls.Add(this.flowLayoutPanelRSS);
            this.pnlRSSNews.Location = new System.Drawing.Point(455, 12);
            this.pnlRSSNews.Name = "pnlRSSNews";
            this.pnlRSSNews.Size = new System.Drawing.Size(393, 489);
            this.pnlRSSNews.TabIndex = 11;
            // 
            // flowLayoutPanelRSS
            // 
            this.flowLayoutPanelRSS.AutoScroll = true;
            this.flowLayoutPanelRSS.Dock = System.Windows.Forms.DockStyle.Fill;
            this.flowLayoutPanelRSS.Location = new System.Drawing.Point(0, 0);
            this.flowLayoutPanelRSS.Name = "flowLayoutPanelRSS";
            this.flowLayoutPanelRSS.Size = new System.Drawing.Size(393, 489);
            this.flowLayoutPanelRSS.TabIndex = 0;
            // 
            // pnlRefresh
            // 
            this.pnlRefresh.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.pnlRefresh.Controls.Add(this.btnRSSUpdate);
            this.pnlRefresh.Controls.Add(this.btnTwtUpdate);
            this.pnlRefresh.Controls.Add(this.btnWeUpdate);
            this.pnlRefresh.Controls.Add(this.lblRSSLastUpdate);
            this.pnlRefresh.Controls.Add(this.lblTwtLastUpdate);
            this.pnlRefresh.Controls.Add(this.lblWeLastUpdate);
            this.pnlRefresh.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.pnlRefresh.Location = new System.Drawing.Point(0, 695);
            this.pnlRefresh.Name = "pnlRefresh";
            this.pnlRefresh.Size = new System.Drawing.Size(1213, 30);
            this.pnlRefresh.TabIndex = 12;
            // 
            // lblRSSLastUpdate
            // 
            this.lblRSSLastUpdate.AutoSize = true;
            this.lblRSSLastUpdate.Font = new System.Drawing.Font("Microsoft JhengHei", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblRSSLastUpdate.ForeColor = System.Drawing.Color.White;
            this.lblRSSLastUpdate.Location = new System.Drawing.Point(226, 7);
            this.lblRSSLastUpdate.Name = "lblRSSLastUpdate";
            this.lblRSSLastUpdate.Size = new System.Drawing.Size(38, 15);
            this.lblRSSLastUpdate.TabIndex = 5;
            this.lblRSSLastUpdate.Text = "00:00";
            // 
            // lblTwtLastUpdate
            // 
            this.lblTwtLastUpdate.AutoSize = true;
            this.lblTwtLastUpdate.Font = new System.Drawing.Font("Microsoft JhengHei", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblTwtLastUpdate.ForeColor = System.Drawing.Color.White;
            this.lblTwtLastUpdate.Location = new System.Drawing.Point(131, 7);
            this.lblTwtLastUpdate.Name = "lblTwtLastUpdate";
            this.lblTwtLastUpdate.Size = new System.Drawing.Size(38, 15);
            this.lblTwtLastUpdate.TabIndex = 3;
            this.lblTwtLastUpdate.Text = "00:00";
            // 
            // lblWeLastUpdate
            // 
            this.lblWeLastUpdate.AutoSize = true;
            this.lblWeLastUpdate.Font = new System.Drawing.Font("Microsoft JhengHei", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblWeLastUpdate.ForeColor = System.Drawing.Color.White;
            this.lblWeLastUpdate.Location = new System.Drawing.Point(40, 7);
            this.lblWeLastUpdate.Name = "lblWeLastUpdate";
            this.lblWeLastUpdate.Size = new System.Drawing.Size(38, 15);
            this.lblWeLastUpdate.TabIndex = 1;
            this.lblWeLastUpdate.Text = "00:00";
            // 
            // txtHashTest
            // 
            this.txtHashTest.Font = new System.Drawing.Font("Microsoft JhengHei", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtHashTest.Location = new System.Drawing.Point(96, 12);
            this.txtHashTest.Name = "txtHashTest";
            this.txtHashTest.Size = new System.Drawing.Size(121, 22);
            this.txtHashTest.TabIndex = 13;
            this.txtHashTest.Text = "ebgames";
            // 
            // comboTweetLimit
            // 
            this.comboTweetLimit.Font = new System.Drawing.Font("Microsoft JhengHei", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.comboTweetLimit.FormattingEnabled = true;
            this.comboTweetLimit.Items.AddRange(new object[] {
            "5",
            "10",
            "20"});
            this.comboTweetLimit.Location = new System.Drawing.Point(96, 40);
            this.comboTweetLimit.Name = "comboTweetLimit";
            this.comboTweetLimit.Size = new System.Drawing.Size(44, 23);
            this.comboTweetLimit.TabIndex = 14;
            this.comboTweetLimit.Text = "5";
            // 
            // txtAddNote
            // 
            this.txtAddNote.Font = new System.Drawing.Font("Microsoft JhengHei", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtAddNote.Location = new System.Drawing.Point(3, 419);
            this.txtAddNote.Multiline = true;
            this.txtAddNote.Name = "txtAddNote";
            this.txtAddNote.ScrollBars = System.Windows.Forms.ScrollBars.Vertical;
            this.txtAddNote.Size = new System.Drawing.Size(209, 66);
            this.txtAddNote.TabIndex = 0;
            this.txtAddNote.Text = "Create a new note...";
            // 
            // pnlToDo
            // 
            this.pnlToDo.Controls.Add(this.lblAddNote);
            this.pnlToDo.Controls.Add(this.flowLayoutPanelToDo);
            this.pnlToDo.Controls.Add(this.txtAddNote);
            this.pnlToDo.Location = new System.Drawing.Point(858, 13);
            this.pnlToDo.Name = "pnlToDo";
            this.pnlToDo.Size = new System.Drawing.Size(348, 488);
            this.pnlToDo.TabIndex = 16;
            // 
            // flowLayoutPanelToDo
            // 
            this.flowLayoutPanelToDo.AutoScroll = true;
            this.flowLayoutPanelToDo.Location = new System.Drawing.Point(3, 3);
            this.flowLayoutPanelToDo.Name = "flowLayoutPanelToDo";
            this.flowLayoutPanelToDo.Size = new System.Drawing.Size(342, 410);
            this.flowLayoutPanelToDo.TabIndex = 0;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft JhengHei", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.ForeColor = System.Drawing.Color.White;
            this.label1.Location = new System.Drawing.Point(6, 15);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(69, 15);
            this.label1.TabIndex = 17;
            this.label1.Text = "Hashtag (#)";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Microsoft JhengHei", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.ForeColor = System.Drawing.Color.White;
            this.label2.Location = new System.Drawing.Point(6, 43);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(88, 15);
            this.label2.TabIndex = 18;
            this.label2.Text = "Tweets to show";
            // 
            // tabSettings
            // 
            this.tabSettings.Controls.Add(this.tabWeatherSettings);
            this.tabSettings.Controls.Add(this.tabTwitterSettings);
            this.tabSettings.Controls.Add(this.tabRSSSettings);
            this.tabSettings.Controls.Add(this.tabNotesSettings);
            this.tabSettings.Location = new System.Drawing.Point(16, 564);
            this.tabSettings.Name = "tabSettings";
            this.tabSettings.SelectedIndex = 0;
            this.tabSettings.Size = new System.Drawing.Size(426, 125);
            this.tabSettings.TabIndex = 19;
            // 
            // tabWeatherSettings
            // 
            this.tabWeatherSettings.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(27)))), ((int)(((byte)(38)))), ((int)(((byte)(44)))));
            this.tabWeatherSettings.Controls.Add(this.lblCitySettings);
            this.tabWeatherSettings.Controls.Add(this.cmbCitySettings);
            this.tabWeatherSettings.Controls.Add(this.radioButton2);
            this.tabWeatherSettings.Controls.Add(this.radioButton1);
            this.tabWeatherSettings.Location = new System.Drawing.Point(4, 22);
            this.tabWeatherSettings.Name = "tabWeatherSettings";
            this.tabWeatherSettings.Padding = new System.Windows.Forms.Padding(3);
            this.tabWeatherSettings.Size = new System.Drawing.Size(418, 99);
            this.tabWeatherSettings.TabIndex = 0;
            this.tabWeatherSettings.Text = "Weather";
            // 
            // lblCitySettings
            // 
            this.lblCitySettings.AutoSize = true;
            this.lblCitySettings.Font = new System.Drawing.Font("Microsoft JhengHei", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblCitySettings.ForeColor = System.Drawing.Color.White;
            this.lblCitySettings.Location = new System.Drawing.Point(4, 14);
            this.lblCitySettings.Name = "lblCitySettings";
            this.lblCitySettings.Size = new System.Drawing.Size(27, 15);
            this.lblCitySettings.TabIndex = 3;
            this.lblCitySettings.Text = "City";
            // 
            // cmbCitySettings
            // 
            this.cmbCitySettings.FormattingEnabled = true;
            this.cmbCitySettings.Items.AddRange(new object[] {
            "Toronto"});
            this.cmbCitySettings.Location = new System.Drawing.Point(37, 11);
            this.cmbCitySettings.Name = "cmbCitySettings";
            this.cmbCitySettings.Size = new System.Drawing.Size(121, 21);
            this.cmbCitySettings.TabIndex = 2;
            // 
            // radioButton2
            // 
            this.radioButton2.AutoSize = true;
            this.radioButton2.Font = new System.Drawing.Font("Microsoft JhengHei", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.radioButton2.ForeColor = System.Drawing.Color.White;
            this.radioButton2.Location = new System.Drawing.Point(49, 49);
            this.radioButton2.Name = "radioButton2";
            this.radioButton2.Size = new System.Drawing.Size(35, 19);
            this.radioButton2.TabIndex = 1;
            this.radioButton2.Text = "°F";
            this.radioButton2.UseVisualStyleBackColor = true;
            // 
            // radioButton1
            // 
            this.radioButton1.AutoSize = true;
            this.radioButton1.Checked = true;
            this.radioButton1.Font = new System.Drawing.Font("Microsoft JhengHei", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.radioButton1.ForeColor = System.Drawing.Color.White;
            this.radioButton1.Location = new System.Drawing.Point(7, 49);
            this.radioButton1.Name = "radioButton1";
            this.radioButton1.Size = new System.Drawing.Size(36, 19);
            this.radioButton1.TabIndex = 0;
            this.radioButton1.TabStop = true;
            this.radioButton1.Text = "°C";
            this.radioButton1.UseVisualStyleBackColor = true;
            // 
            // tabTwitterSettings
            // 
            this.tabTwitterSettings.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(27)))), ((int)(((byte)(38)))), ((int)(((byte)(44)))));
            this.tabTwitterSettings.Controls.Add(this.label1);
            this.tabTwitterSettings.Controls.Add(this.label2);
            this.tabTwitterSettings.Controls.Add(this.txtHashTest);
            this.tabTwitterSettings.Controls.Add(this.comboTweetLimit);
            this.tabTwitterSettings.Location = new System.Drawing.Point(4, 22);
            this.tabTwitterSettings.Name = "tabTwitterSettings";
            this.tabTwitterSettings.Padding = new System.Windows.Forms.Padding(3);
            this.tabTwitterSettings.Size = new System.Drawing.Size(418, 99);
            this.tabTwitterSettings.TabIndex = 1;
            this.tabTwitterSettings.Text = "Twitter";
            // 
            // tabRSSSettings
            // 
            this.tabRSSSettings.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(27)))), ((int)(((byte)(38)))), ((int)(((byte)(44)))));
            this.tabRSSSettings.Controls.Add(this.comboBox1);
            this.tabRSSSettings.Controls.Add(this.label3);
            this.tabRSSSettings.Location = new System.Drawing.Point(4, 22);
            this.tabRSSSettings.Name = "tabRSSSettings";
            this.tabRSSSettings.Padding = new System.Windows.Forms.Padding(3);
            this.tabRSSSettings.Size = new System.Drawing.Size(418, 99);
            this.tabRSSSettings.TabIndex = 2;
            this.tabRSSSettings.Text = "RSS";
            // 
            // comboBox1
            // 
            this.comboBox1.FormattingEnabled = true;
            this.comboBox1.Location = new System.Drawing.Point(59, 7);
            this.comboBox1.Name = "comboBox1";
            this.comboBox1.Size = new System.Drawing.Size(121, 21);
            this.comboBox1.TabIndex = 1;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Microsoft JhengHei", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.ForeColor = System.Drawing.Color.White;
            this.label3.Location = new System.Drawing.Point(6, 10);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(43, 15);
            this.label3.TabIndex = 0;
            this.label3.Text = "Source";
            // 
            // tabNotesSettings
            // 
            this.tabNotesSettings.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(27)))), ((int)(((byte)(38)))), ((int)(((byte)(44)))));
            this.tabNotesSettings.Controls.Add(this.label4);
            this.tabNotesSettings.Controls.Add(this.radioButton6);
            this.tabNotesSettings.Controls.Add(this.radioButton5);
            this.tabNotesSettings.Controls.Add(this.radioButton4);
            this.tabNotesSettings.Controls.Add(this.radioButton3);
            this.tabNotesSettings.Controls.Add(this.pictureBox1);
            this.tabNotesSettings.ForeColor = System.Drawing.Color.White;
            this.tabNotesSettings.Location = new System.Drawing.Point(4, 22);
            this.tabNotesSettings.Name = "tabNotesSettings";
            this.tabNotesSettings.Padding = new System.Windows.Forms.Padding(3);
            this.tabNotesSettings.Size = new System.Drawing.Size(418, 99);
            this.tabNotesSettings.TabIndex = 3;
            this.tabNotesSettings.Text = "Notes";
            // 
            // radioButton6
            // 
            this.radioButton6.AutoSize = true;
            this.radioButton6.Location = new System.Drawing.Point(8, 61);
            this.radioButton6.Name = "radioButton6";
            this.radioButton6.Size = new System.Drawing.Size(45, 17);
            this.radioButton6.TabIndex = 3;
            this.radioButton6.Text = "Red";
            this.radioButton6.UseVisualStyleBackColor = true;
            // 
            // radioButton5
            // 
            this.radioButton5.AutoSize = true;
            this.radioButton5.Location = new System.Drawing.Point(192, 20);
            this.radioButton5.Name = "radioButton5";
            this.radioButton5.Size = new System.Drawing.Size(46, 17);
            this.radioButton5.TabIndex = 2;
            this.radioButton5.Text = "Blue";
            this.radioButton5.UseVisualStyleBackColor = true;
            // 
            // radioButton4
            // 
            this.radioButton4.AutoSize = true;
            this.radioButton4.Location = new System.Drawing.Point(8, 20);
            this.radioButton4.Name = "radioButton4";
            this.radioButton4.Size = new System.Drawing.Size(54, 17);
            this.radioButton4.TabIndex = 1;
            this.radioButton4.Text = "Green";
            this.radioButton4.UseVisualStyleBackColor = true;
            // 
            // radioButton3
            // 
            this.radioButton3.AutoSize = true;
            this.radioButton3.Checked = true;
            this.radioButton3.Location = new System.Drawing.Point(192, 61);
            this.radioButton3.Name = "radioButton3";
            this.radioButton3.Size = new System.Drawing.Size(56, 17);
            this.radioButton3.TabIndex = 0;
            this.radioButton3.TabStop = true;
            this.radioButton3.Text = "Yellow";
            this.radioButton3.UseVisualStyleBackColor = true;
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Microsoft JhengHei", 6.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.Location = new System.Drawing.Point(286, 82);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(132, 14);
            this.label4.TabIndex = 5;
            this.label4.Text = "All notes are yellow by default.";
            // 
            // pictureBox1
            // 
            this.pictureBox1.BackColor = System.Drawing.Color.Transparent;
            this.pictureBox1.Image = global::Dashboard_WF.Properties.Resources.notes_color;
            this.pictureBox1.Location = new System.Drawing.Point(68, 3);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(118, 90);
            this.pictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pictureBox1.TabIndex = 4;
            this.pictureBox1.TabStop = false;
            // 
            // btnRSSUpdate
            // 
            this.btnRSSUpdate.Image = global::Dashboard_WF.Properties.Resources.rss;
            this.btnRSSUpdate.InitialImage = null;
            this.btnRSSUpdate.Location = new System.Drawing.Point(188, 2);
            this.btnRSSUpdate.Name = "btnRSSUpdate";
            this.btnRSSUpdate.Size = new System.Drawing.Size(32, 23);
            this.btnRSSUpdate.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.btnRSSUpdate.TabIndex = 16;
            this.btnRSSUpdate.TabStop = false;
            this.btnRSSUpdate.Click += new System.EventHandler(this.BtnRSSUpdate_Click);
            // 
            // btnTwtUpdate
            // 
            this.btnTwtUpdate.Image = global::Dashboard_WF.Properties.Resources.twitter;
            this.btnTwtUpdate.InitialImage = null;
            this.btnTwtUpdate.Location = new System.Drawing.Point(94, 2);
            this.btnTwtUpdate.Name = "btnTwtUpdate";
            this.btnTwtUpdate.Size = new System.Drawing.Size(32, 23);
            this.btnTwtUpdate.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.btnTwtUpdate.TabIndex = 15;
            this.btnTwtUpdate.TabStop = false;
            this.btnTwtUpdate.Click += new System.EventHandler(this.BtnTwtUpdate_Click);
            // 
            // btnWeUpdate
            // 
            this.btnWeUpdate.Image = global::Dashboard_WF.Properties.Resources.weather_2;
            this.btnWeUpdate.InitialImage = null;
            this.btnWeUpdate.Location = new System.Drawing.Point(3, 2);
            this.btnWeUpdate.Name = "btnWeUpdate";
            this.btnWeUpdate.Size = new System.Drawing.Size(32, 23);
            this.btnWeUpdate.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.btnWeUpdate.TabIndex = 14;
            this.btnWeUpdate.TabStop = false;
            this.btnWeUpdate.Click += new System.EventHandler(this.BtnWeUpdate_Click);
            // 
            // lblAddNote
            // 
            this.lblAddNote.BackColor = System.Drawing.Color.LightSkyBlue;
            this.lblAddNote.Font = new System.Drawing.Font("Microsoft JhengHei", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblAddNote.ForeColor = System.Drawing.Color.White;
            this.lblAddNote.Location = new System.Drawing.Point(218, 462);
            this.lblAddNote.Name = "lblAddNote";
            this.lblAddNote.Size = new System.Drawing.Size(69, 23);
            this.lblAddNote.TabIndex = 2;
            this.lblAddNote.Text = "Add";
            this.lblAddNote.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.lblAddNote.Click += new System.EventHandler(this.LblAddNote_Click);
            // 
            // frmMain
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1213, 725);
            this.Controls.Add(this.tabSettings);
            this.Controls.Add(this.pnlToDo);
            this.Controls.Add(this.pnlRefresh);
            this.Controls.Add(this.panel1);
            this.Controls.Add(this.pnlRSSNews);
            this.Controls.Add(this.pnlWeather);
            this.Name = "frmMain";
            this.ShowIcon = false;
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Dashboard";
            this.panel1.ResumeLayout(false);
            this.pnlWeather.ResumeLayout(false);
            this.pnlRSSNews.ResumeLayout(false);
            this.pnlRefresh.ResumeLayout(false);
            this.pnlRefresh.PerformLayout();
            this.pnlToDo.ResumeLayout(false);
            this.pnlToDo.PerformLayout();
            this.tabSettings.ResumeLayout(false);
            this.tabWeatherSettings.ResumeLayout(false);
            this.tabWeatherSettings.PerformLayout();
            this.tabTwitterSettings.ResumeLayout(false);
            this.tabTwitterSettings.PerformLayout();
            this.tabRSSSettings.ResumeLayout(false);
            this.tabRSSSettings.PerformLayout();
            this.tabNotesSettings.ResumeLayout(false);
            this.tabNotesSettings.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.btnRSSUpdate)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.btnTwtUpdate)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.btnWeUpdate)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.FlowLayoutPanel flowLayoutPanel1;
        private System.Windows.Forms.Panel pnlWeather;
        private System.Windows.Forms.FlowLayoutPanel flowLayoutPanel2;
        private System.Windows.Forms.Panel pnlRSSNews;
        private System.Windows.Forms.FlowLayoutPanel flowLayoutPanelRSS;
        private System.Windows.Forms.Panel pnlRefresh;
        private System.Windows.Forms.PictureBox btnRSSUpdate;
        private System.Windows.Forms.PictureBox btnTwtUpdate;
        private System.Windows.Forms.PictureBox btnWeUpdate;
        private System.Windows.Forms.Label lblRSSLastUpdate;
        private System.Windows.Forms.Label lblTwtLastUpdate;
        private System.Windows.Forms.Label lblWeLastUpdate;
        private System.Windows.Forms.TextBox txtHashTest;
        private System.Windows.Forms.ComboBox comboTweetLimit;
        private System.Windows.Forms.TextBox txtAddNote;
        private System.Windows.Forms.Panel pnlToDo;
        private System.Windows.Forms.FlowLayoutPanel flowLayoutPanelToDo;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.TabControl tabSettings;
        private System.Windows.Forms.TabPage tabWeatherSettings;
        private System.Windows.Forms.TabPage tabTwitterSettings;
        private System.Windows.Forms.TabPage tabRSSSettings;
        private System.Windows.Forms.TabPage tabNotesSettings;
        private System.Windows.Forms.Label lblCitySettings;
        private System.Windows.Forms.ComboBox cmbCitySettings;
        private System.Windows.Forms.RadioButton radioButton2;
        private System.Windows.Forms.RadioButton radioButton1;
        private System.Windows.Forms.ComboBox comboBox1;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.RadioButton radioButton6;
        private System.Windows.Forms.RadioButton radioButton5;
        private System.Windows.Forms.RadioButton radioButton4;
        private System.Windows.Forms.RadioButton radioButton3;
        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label lblAddNote;
    }
}

