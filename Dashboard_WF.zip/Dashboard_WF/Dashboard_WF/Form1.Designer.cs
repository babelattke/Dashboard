﻿namespace Dashboard_WF
{
    partial class frmMain
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.panel1 = new System.Windows.Forms.Panel();
            this.flowLayoutPanel1 = new System.Windows.Forms.FlowLayoutPanel();
            this.pnlWeather = new System.Windows.Forms.Panel();
            this.flowLayoutPanel2 = new System.Windows.Forms.FlowLayoutPanel();
            this.pnlRSSNews = new System.Windows.Forms.Panel();
            this.flowLayoutPanelRSS = new System.Windows.Forms.FlowLayoutPanel();
            this.pnlRefresh = new System.Windows.Forms.Panel();
            this.lblWeLastUpdate = new System.Windows.Forms.Label();
            this.lblTwtLastUpdate = new System.Windows.Forms.Label();
            this.lblRSSLastUpdate = new System.Windows.Forms.Label();
            this.btnWeUpdate = new System.Windows.Forms.PictureBox();
            this.btnTwtUpdate = new System.Windows.Forms.PictureBox();
            this.btnRSSUpdate = new System.Windows.Forms.PictureBox();
            this.panel1.SuspendLayout();
            this.pnlWeather.SuspendLayout();
            this.pnlRSSNews.SuspendLayout();
            this.pnlRefresh.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.btnWeUpdate)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.btnTwtUpdate)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.btnRSSUpdate)).BeginInit();
            this.SuspendLayout();
            // 
            // panel1
            // 
            this.panel1.Controls.Add(this.flowLayoutPanel1);
            this.panel1.Location = new System.Drawing.Point(13, 131);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(429, 370);
            this.panel1.TabIndex = 9;
            // 
            // flowLayoutPanel1
            // 
            this.flowLayoutPanel1.AutoScroll = true;
            this.flowLayoutPanel1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.flowLayoutPanel1.Location = new System.Drawing.Point(0, 0);
            this.flowLayoutPanel1.Name = "flowLayoutPanel1";
            this.flowLayoutPanel1.Size = new System.Drawing.Size(429, 370);
            this.flowLayoutPanel1.TabIndex = 0;
            // 
            // pnlWeather
            // 
            this.pnlWeather.Controls.Add(this.flowLayoutPanel2);
            this.pnlWeather.Location = new System.Drawing.Point(13, 12);
            this.pnlWeather.Name = "pnlWeather";
            this.pnlWeather.Size = new System.Drawing.Size(288, 113);
            this.pnlWeather.TabIndex = 10;
            // 
            // flowLayoutPanel2
            // 
            this.flowLayoutPanel2.Dock = System.Windows.Forms.DockStyle.Fill;
            this.flowLayoutPanel2.Location = new System.Drawing.Point(0, 0);
            this.flowLayoutPanel2.Name = "flowLayoutPanel2";
            this.flowLayoutPanel2.Size = new System.Drawing.Size(288, 113);
            this.flowLayoutPanel2.TabIndex = 0;
            // 
            // pnlRSSNews
            // 
            this.pnlRSSNews.Controls.Add(this.flowLayoutPanelRSS);
            this.pnlRSSNews.Location = new System.Drawing.Point(455, 12);
            this.pnlRSSNews.Name = "pnlRSSNews";
            this.pnlRSSNews.Size = new System.Drawing.Size(393, 489);
            this.pnlRSSNews.TabIndex = 11;
            // 
            // flowLayoutPanelRSS
            // 
            this.flowLayoutPanelRSS.AutoScroll = true;
            this.flowLayoutPanelRSS.Dock = System.Windows.Forms.DockStyle.Fill;
            this.flowLayoutPanelRSS.Location = new System.Drawing.Point(0, 0);
            this.flowLayoutPanelRSS.Name = "flowLayoutPanelRSS";
            this.flowLayoutPanelRSS.Size = new System.Drawing.Size(393, 489);
            this.flowLayoutPanelRSS.TabIndex = 0;
            // 
            // pnlRefresh
            // 
            this.pnlRefresh.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.pnlRefresh.Controls.Add(this.btnRSSUpdate);
            this.pnlRefresh.Controls.Add(this.btnTwtUpdate);
            this.pnlRefresh.Controls.Add(this.btnWeUpdate);
            this.pnlRefresh.Controls.Add(this.lblRSSLastUpdate);
            this.pnlRefresh.Controls.Add(this.lblTwtLastUpdate);
            this.pnlRefresh.Controls.Add(this.lblWeLastUpdate);
            this.pnlRefresh.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.pnlRefresh.Location = new System.Drawing.Point(0, 538);
            this.pnlRefresh.Name = "pnlRefresh";
            this.pnlRefresh.Size = new System.Drawing.Size(1221, 30);
            this.pnlRefresh.TabIndex = 12;
            // 
            // lblWeLastUpdate
            // 
            this.lblWeLastUpdate.AutoSize = true;
            this.lblWeLastUpdate.Location = new System.Drawing.Point(40, 7);
            this.lblWeLastUpdate.Name = "lblWeLastUpdate";
            this.lblWeLastUpdate.Size = new System.Drawing.Size(34, 13);
            this.lblWeLastUpdate.TabIndex = 1;
            this.lblWeLastUpdate.Text = "00:00";
            // 
            // lblTwtLastUpdate
            // 
            this.lblTwtLastUpdate.AutoSize = true;
            this.lblTwtLastUpdate.Location = new System.Drawing.Point(124, 7);
            this.lblTwtLastUpdate.Name = "lblTwtLastUpdate";
            this.lblTwtLastUpdate.Size = new System.Drawing.Size(34, 13);
            this.lblTwtLastUpdate.TabIndex = 3;
            this.lblTwtLastUpdate.Text = "00:00";
            // 
            // lblRSSLastUpdate
            // 
            this.lblRSSLastUpdate.AutoSize = true;
            this.lblRSSLastUpdate.Location = new System.Drawing.Point(210, 7);
            this.lblRSSLastUpdate.Name = "lblRSSLastUpdate";
            this.lblRSSLastUpdate.Size = new System.Drawing.Size(34, 13);
            this.lblRSSLastUpdate.TabIndex = 5;
            this.lblRSSLastUpdate.Text = "00:00";
            // 
            // btnWeUpdate
            // 
            this.btnWeUpdate.Image = global::Dashboard_WF.Properties.Resources.weather;
            this.btnWeUpdate.InitialImage = null;
            this.btnWeUpdate.Location = new System.Drawing.Point(3, 2);
            this.btnWeUpdate.Name = "btnWeUpdate";
            this.btnWeUpdate.Size = new System.Drawing.Size(32, 23);
            this.btnWeUpdate.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.btnWeUpdate.TabIndex = 14;
            this.btnWeUpdate.TabStop = false;
            this.btnWeUpdate.Click += new System.EventHandler(this.BtnWeUpdate_Click);
            // 
            // btnTwtUpdate
            // 
            this.btnTwtUpdate.Image = global::Dashboard_WF.Properties.Resources.twitter;
            this.btnTwtUpdate.InitialImage = null;
            this.btnTwtUpdate.Location = new System.Drawing.Point(87, 2);
            this.btnTwtUpdate.Name = "btnTwtUpdate";
            this.btnTwtUpdate.Size = new System.Drawing.Size(32, 23);
            this.btnTwtUpdate.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.btnTwtUpdate.TabIndex = 15;
            this.btnTwtUpdate.TabStop = false;
            this.btnTwtUpdate.Click += new System.EventHandler(this.BtnTwtUpdate_Click);
            // 
            // btnRSSUpdate
            // 
            this.btnRSSUpdate.Image = global::Dashboard_WF.Properties.Resources.rss;
            this.btnRSSUpdate.InitialImage = null;
            this.btnRSSUpdate.Location = new System.Drawing.Point(172, 2);
            this.btnRSSUpdate.Name = "btnRSSUpdate";
            this.btnRSSUpdate.Size = new System.Drawing.Size(32, 23);
            this.btnRSSUpdate.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.btnRSSUpdate.TabIndex = 16;
            this.btnRSSUpdate.TabStop = false;
            this.btnRSSUpdate.Click += new System.EventHandler(this.BtnRSSUpdate_Click);
            // 
            // frmMain
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1221, 568);
            this.Controls.Add(this.pnlRefresh);
            this.Controls.Add(this.panel1);
            this.Controls.Add(this.pnlRSSNews);
            this.Controls.Add(this.pnlWeather);
            this.Name = "frmMain";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Dashboard";
            this.WindowState = System.Windows.Forms.FormWindowState.Maximized;
            this.panel1.ResumeLayout(false);
            this.pnlWeather.ResumeLayout(false);
            this.pnlRSSNews.ResumeLayout(false);
            this.pnlRefresh.ResumeLayout(false);
            this.pnlRefresh.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.btnWeUpdate)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.btnTwtUpdate)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.btnRSSUpdate)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.FlowLayoutPanel flowLayoutPanel1;
        private System.Windows.Forms.Panel pnlWeather;
        private System.Windows.Forms.FlowLayoutPanel flowLayoutPanel2;
        private System.Windows.Forms.Panel pnlRSSNews;
        private System.Windows.Forms.FlowLayoutPanel flowLayoutPanelRSS;
        private System.Windows.Forms.Panel pnlRefresh;
        private System.Windows.Forms.PictureBox btnRSSUpdate;
        private System.Windows.Forms.PictureBox btnTwtUpdate;
        private System.Windows.Forms.PictureBox btnWeUpdate;
        private System.Windows.Forms.Label lblRSSLastUpdate;
        private System.Windows.Forms.Label lblTwtLastUpdate;
        private System.Windows.Forms.Label lblWeLastUpdate;
    }
}

