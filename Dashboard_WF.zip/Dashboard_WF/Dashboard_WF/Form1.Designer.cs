﻿namespace Dashboard_WF
{
    partial class frmMain
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.panel1 = new System.Windows.Forms.Panel();
            this.flowLayoutPanel1 = new System.Windows.Forms.FlowLayoutPanel();
            this.pnlWeather = new System.Windows.Forms.Panel();
            this.flowLayoutPanel2 = new System.Windows.Forms.FlowLayoutPanel();
            this.pnlRSSNews = new System.Windows.Forms.Panel();
            this.flowLayoutPanelRSS = new System.Windows.Forms.FlowLayoutPanel();
            this.pnlRefresh = new System.Windows.Forms.Panel();
            this.lblRSSLastUpdate = new System.Windows.Forms.Label();
            this.lblTwtLastUpdate = new System.Windows.Forms.Label();
            this.lblWeLastUpdate = new System.Windows.Forms.Label();
            this.txtHashTest = new System.Windows.Forms.TextBox();
            this.comboTweetLimit = new System.Windows.Forms.ComboBox();
            this.btnAddNote = new System.Windows.Forms.Button();
            this.txtAddNote = new System.Windows.Forms.TextBox();
            this.pnlToDo = new System.Windows.Forms.Panel();
            this.flowLayoutPanelToDo = new System.Windows.Forms.FlowLayoutPanel();
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.btnRSSUpdate = new System.Windows.Forms.PictureBox();
            this.btnTwtUpdate = new System.Windows.Forms.PictureBox();
            this.btnWeUpdate = new System.Windows.Forms.PictureBox();
            this.panel1.SuspendLayout();
            this.pnlWeather.SuspendLayout();
            this.pnlRSSNews.SuspendLayout();
            this.pnlRefresh.SuspendLayout();
            this.pnlToDo.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.btnRSSUpdate)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.btnTwtUpdate)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.btnWeUpdate)).BeginInit();
            this.SuspendLayout();
            // 
            // panel1
            // 
            this.panel1.Controls.Add(this.flowLayoutPanel1);
            this.panel1.Location = new System.Drawing.Point(13, 131);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(429, 370);
            this.panel1.TabIndex = 9;
            // 
            // flowLayoutPanel1
            // 
            this.flowLayoutPanel1.AutoScroll = true;
            this.flowLayoutPanel1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.flowLayoutPanel1.Location = new System.Drawing.Point(0, 0);
            this.flowLayoutPanel1.Name = "flowLayoutPanel1";
            this.flowLayoutPanel1.Size = new System.Drawing.Size(429, 370);
            this.flowLayoutPanel1.TabIndex = 0;
            // 
            // pnlWeather
            // 
            this.pnlWeather.Controls.Add(this.flowLayoutPanel2);
            this.pnlWeather.Location = new System.Drawing.Point(13, 12);
            this.pnlWeather.Name = "pnlWeather";
            this.pnlWeather.Size = new System.Drawing.Size(288, 113);
            this.pnlWeather.TabIndex = 10;
            // 
            // flowLayoutPanel2
            // 
            this.flowLayoutPanel2.Dock = System.Windows.Forms.DockStyle.Fill;
            this.flowLayoutPanel2.Location = new System.Drawing.Point(0, 0);
            this.flowLayoutPanel2.Name = "flowLayoutPanel2";
            this.flowLayoutPanel2.Size = new System.Drawing.Size(288, 113);
            this.flowLayoutPanel2.TabIndex = 0;
            // 
            // pnlRSSNews
            // 
            this.pnlRSSNews.Controls.Add(this.flowLayoutPanelRSS);
            this.pnlRSSNews.Location = new System.Drawing.Point(455, 12);
            this.pnlRSSNews.Name = "pnlRSSNews";
            this.pnlRSSNews.Size = new System.Drawing.Size(393, 489);
            this.pnlRSSNews.TabIndex = 11;
            // 
            // flowLayoutPanelRSS
            // 
            this.flowLayoutPanelRSS.AutoScroll = true;
            this.flowLayoutPanelRSS.Dock = System.Windows.Forms.DockStyle.Fill;
            this.flowLayoutPanelRSS.Location = new System.Drawing.Point(0, 0);
            this.flowLayoutPanelRSS.Name = "flowLayoutPanelRSS";
            this.flowLayoutPanelRSS.Size = new System.Drawing.Size(393, 489);
            this.flowLayoutPanelRSS.TabIndex = 0;
            // 
            // pnlRefresh
            // 
            this.pnlRefresh.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.pnlRefresh.Controls.Add(this.btnRSSUpdate);
            this.pnlRefresh.Controls.Add(this.btnTwtUpdate);
            this.pnlRefresh.Controls.Add(this.btnWeUpdate);
            this.pnlRefresh.Controls.Add(this.lblRSSLastUpdate);
            this.pnlRefresh.Controls.Add(this.lblTwtLastUpdate);
            this.pnlRefresh.Controls.Add(this.lblWeLastUpdate);
            this.pnlRefresh.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.pnlRefresh.Location = new System.Drawing.Point(0, 695);
            this.pnlRefresh.Name = "pnlRefresh";
            this.pnlRefresh.Size = new System.Drawing.Size(1221, 30);
            this.pnlRefresh.TabIndex = 12;
            // 
            // lblRSSLastUpdate
            // 
            this.lblRSSLastUpdate.AutoSize = true;
            this.lblRSSLastUpdate.Location = new System.Drawing.Point(210, 7);
            this.lblRSSLastUpdate.Name = "lblRSSLastUpdate";
            this.lblRSSLastUpdate.Size = new System.Drawing.Size(34, 13);
            this.lblRSSLastUpdate.TabIndex = 5;
            this.lblRSSLastUpdate.Text = "00:00";
            // 
            // lblTwtLastUpdate
            // 
            this.lblTwtLastUpdate.AutoSize = true;
            this.lblTwtLastUpdate.Location = new System.Drawing.Point(124, 7);
            this.lblTwtLastUpdate.Name = "lblTwtLastUpdate";
            this.lblTwtLastUpdate.Size = new System.Drawing.Size(34, 13);
            this.lblTwtLastUpdate.TabIndex = 3;
            this.lblTwtLastUpdate.Text = "00:00";
            // 
            // lblWeLastUpdate
            // 
            this.lblWeLastUpdate.AutoSize = true;
            this.lblWeLastUpdate.Location = new System.Drawing.Point(40, 7);
            this.lblWeLastUpdate.Name = "lblWeLastUpdate";
            this.lblWeLastUpdate.Size = new System.Drawing.Size(34, 13);
            this.lblWeLastUpdate.TabIndex = 1;
            this.lblWeLastUpdate.Text = "00:00";
            // 
            // txtHashTest
            // 
            this.txtHashTest.Font = new System.Drawing.Font("Microsoft JhengHei", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtHashTest.Location = new System.Drawing.Point(103, 507);
            this.txtHashTest.Name = "txtHashTest";
            this.txtHashTest.Size = new System.Drawing.Size(121, 22);
            this.txtHashTest.TabIndex = 13;
            this.txtHashTest.Text = "ebgames";
            // 
            // comboTweetLimit
            // 
            this.comboTweetLimit.Font = new System.Drawing.Font("Microsoft JhengHei", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.comboTweetLimit.FormattingEnabled = true;
            this.comboTweetLimit.Items.AddRange(new object[] {
            "5",
            "10",
            "20"});
            this.comboTweetLimit.Location = new System.Drawing.Point(103, 535);
            this.comboTweetLimit.Name = "comboTweetLimit";
            this.comboTweetLimit.Size = new System.Drawing.Size(44, 23);
            this.comboTweetLimit.TabIndex = 14;
            this.comboTweetLimit.Text = "5";
            // 
            // btnAddNote
            // 
            this.btnAddNote.Location = new System.Drawing.Point(218, 462);
            this.btnAddNote.Name = "btnAddNote";
            this.btnAddNote.Size = new System.Drawing.Size(57, 23);
            this.btnAddNote.TabIndex = 1;
            this.btnAddNote.Text = "Add";
            this.btnAddNote.UseVisualStyleBackColor = true;
            this.btnAddNote.Click += new System.EventHandler(this.BtnAddNote_Click);
            // 
            // txtAddNote
            // 
            this.txtAddNote.Location = new System.Drawing.Point(3, 419);
            this.txtAddNote.Multiline = true;
            this.txtAddNote.Name = "txtAddNote";
            this.txtAddNote.ScrollBars = System.Windows.Forms.ScrollBars.Vertical;
            this.txtAddNote.Size = new System.Drawing.Size(209, 66);
            this.txtAddNote.TabIndex = 0;
            this.txtAddNote.Text = "Create a new note...";
            // 
            // pnlToDo
            // 
            this.pnlToDo.Controls.Add(this.flowLayoutPanelToDo);
            this.pnlToDo.Controls.Add(this.btnAddNote);
            this.pnlToDo.Controls.Add(this.txtAddNote);
            this.pnlToDo.Location = new System.Drawing.Point(858, 13);
            this.pnlToDo.Name = "pnlToDo";
            this.pnlToDo.Size = new System.Drawing.Size(348, 488);
            this.pnlToDo.TabIndex = 16;
            // 
            // flowLayoutPanelToDo
            // 
            this.flowLayoutPanelToDo.AutoScroll = true;
            this.flowLayoutPanelToDo.Location = new System.Drawing.Point(3, 3);
            this.flowLayoutPanelToDo.Name = "flowLayoutPanelToDo";
            this.flowLayoutPanelToDo.Size = new System.Drawing.Size(342, 410);
            this.flowLayoutPanelToDo.TabIndex = 0;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(13, 510);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(63, 13);
            this.label1.TabIndex = 17;
            this.label1.Text = "Hashtag (#)";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(13, 538);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(82, 13);
            this.label2.TabIndex = 18;
            this.label2.Text = "Tweets to show";
            // 
            // btnRSSUpdate
            // 
            this.btnRSSUpdate.Image = global::Dashboard_WF.Properties.Resources.rss;
            this.btnRSSUpdate.InitialImage = null;
            this.btnRSSUpdate.Location = new System.Drawing.Point(172, 2);
            this.btnRSSUpdate.Name = "btnRSSUpdate";
            this.btnRSSUpdate.Size = new System.Drawing.Size(32, 23);
            this.btnRSSUpdate.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.btnRSSUpdate.TabIndex = 16;
            this.btnRSSUpdate.TabStop = false;
            this.btnRSSUpdate.Click += new System.EventHandler(this.BtnRSSUpdate_Click);
            // 
            // btnTwtUpdate
            // 
            this.btnTwtUpdate.Image = global::Dashboard_WF.Properties.Resources.twitter;
            this.btnTwtUpdate.InitialImage = null;
            this.btnTwtUpdate.Location = new System.Drawing.Point(87, 2);
            this.btnTwtUpdate.Name = "btnTwtUpdate";
            this.btnTwtUpdate.Size = new System.Drawing.Size(32, 23);
            this.btnTwtUpdate.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.btnTwtUpdate.TabIndex = 15;
            this.btnTwtUpdate.TabStop = false;
            this.btnTwtUpdate.Click += new System.EventHandler(this.BtnTwtUpdate_Click);
            // 
            // btnWeUpdate
            // 
            this.btnWeUpdate.Image = global::Dashboard_WF.Properties.Resources.weather;
            this.btnWeUpdate.InitialImage = null;
            this.btnWeUpdate.Location = new System.Drawing.Point(3, 2);
            this.btnWeUpdate.Name = "btnWeUpdate";
            this.btnWeUpdate.Size = new System.Drawing.Size(32, 23);
            this.btnWeUpdate.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.btnWeUpdate.TabIndex = 14;
            this.btnWeUpdate.TabStop = false;
            this.btnWeUpdate.Click += new System.EventHandler(this.BtnWeUpdate_Click);
            // 
            // frmMain
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1221, 725);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.pnlToDo);
            this.Controls.Add(this.comboTweetLimit);
            this.Controls.Add(this.txtHashTest);
            this.Controls.Add(this.pnlRefresh);
            this.Controls.Add(this.panel1);
            this.Controls.Add(this.pnlRSSNews);
            this.Controls.Add(this.pnlWeather);
            this.Name = "frmMain";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Dashboard";
            this.panel1.ResumeLayout(false);
            this.pnlWeather.ResumeLayout(false);
            this.pnlRSSNews.ResumeLayout(false);
            this.pnlRefresh.ResumeLayout(false);
            this.pnlRefresh.PerformLayout();
            this.pnlToDo.ResumeLayout(false);
            this.pnlToDo.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.btnRSSUpdate)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.btnTwtUpdate)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.btnWeUpdate)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.FlowLayoutPanel flowLayoutPanel1;
        private System.Windows.Forms.Panel pnlWeather;
        private System.Windows.Forms.FlowLayoutPanel flowLayoutPanel2;
        private System.Windows.Forms.Panel pnlRSSNews;
        private System.Windows.Forms.FlowLayoutPanel flowLayoutPanelRSS;
        private System.Windows.Forms.Panel pnlRefresh;
        private System.Windows.Forms.PictureBox btnRSSUpdate;
        private System.Windows.Forms.PictureBox btnTwtUpdate;
        private System.Windows.Forms.PictureBox btnWeUpdate;
        private System.Windows.Forms.Label lblRSSLastUpdate;
        private System.Windows.Forms.Label lblTwtLastUpdate;
        private System.Windows.Forms.Label lblWeLastUpdate;
        private System.Windows.Forms.TextBox txtHashTest;
        private System.Windows.Forms.ComboBox comboTweetLimit;
        private System.Windows.Forms.Button btnAddNote;
        private System.Windows.Forms.TextBox txtAddNote;
        private System.Windows.Forms.Panel pnlToDo;
        private System.Windows.Forms.FlowLayoutPanel flowLayoutPanelToDo;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
    }
}

