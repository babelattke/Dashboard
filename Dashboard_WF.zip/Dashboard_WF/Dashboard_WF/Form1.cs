﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Web.Script.Serialization; //Project
using System.Net; //Project
using Newtonsoft.Json; //Project
using TweetSharp; //Project
using Dashboard_WF.Properties; //Project
using System.Xml.Linq; //Project

namespace Dashboard_WF
{
    public partial class frmMain : Form
    {
        public static string _consumerKey = "8RBVTo0OXpRNksxwucrh1L3Lc"; // Your key
        public static string _consumerSecret = "gVN9iY1mpJgtZtXW4be2raIFsWLumHpMIjdrxrmoB6thFp22LM"; // Your key  
        public static string _accessToken = "50301489-GNFMaQnW2iiUK64nZZC3AtQ7ecV31CCN295zi3Ecs"; // Your key  
        public static string _accessTokenSecret = "OKWZ8m3ftwZltykAgLZIQr1kDdNJ0YJnJHFqDUY9MEKGQ"; // Your key  

        public frmMain()
        {
            InitializeComponent();
            //populateTweets();
            getTwitter();
            populateWeather();            
            //getInfo(); Uncomment once I have some real code in there
        }

        public void getInfo()
        {
            //Here I should add the default or last location.
        }

        private void BtnRefresh_Click(object sender, EventArgs e)
        {
            //getInfo();
            string json = (new WebClient()).DownloadString("http://api.openweathermap.org/data/2.5/weather?id=6167863&appid=3f2635c452b15905dfc6b23c042f2a24");            
            var example2 = new JavaScriptSerializer().Deserialize<GetWeather>(json);
            lblTest.Text = example2.main.temp.ToString();
            
        }

        private void getTwitter()
        {
            
            TwitterService twitterService = new TwitterService(_consumerKey, _consumerSecret);
            twitterService.AuthenticateWith(_accessToken, _accessTokenSecret);

            TweetList[] tweetList = new TweetList[10];

            int tweetcount = 1;
            var tweets_search = twitterService.Search(new SearchOptions { Q = "#ebgames", Resulttype = TwitterSearchResultType.Recent, Count = 10 });
            //Resulttype can be TwitterSearchResultType.Popular or TwitterSearchResultType.Mixed or TwitterSearchResultType.Recent  
            List<TwitterStatus> resultList = new List<TwitterStatus>(tweets_search.Statuses);
            foreach (var tweet in tweets_search.Statuses)
            {
                try
                {
                    //tweet.User.ScreenName;  
                    //tweet.User.Name;   
                    //tweet.Text; // Tweet text  
                    //tweet.RetweetCount; //No of retweet on twitter  
                    //tweet.User.FavouritesCount; //No of Fav mark on twitter  
                    //tweet.User.ProfileImageUrl; //Profile Image of Tweet  
                    //tweet.CreatedDate; //For Tweet posted time  
                    //"https://twitter.com/intent/retweet?tweet_id=" + tweet.Id;  //For Retweet  
                    //"https://twitter.com/intent/tweet?in_reply_to=" + tweet.Id; //For Reply  
                    //"https://twitter.com/intent/favorite?tweet_id=" + tweet.Id; //For Favorite  

                    //Above are the things we can also get using TweetSharp.  
                    //Console.WriteLine("Sr.No: " + tweetcount + "\n" + tweet.User.Name + "\n" + tweet.User.ScreenName + "\n" + "https://twitter.com/intent/retweet?tweet_id=" + tweet.Id);
                    //lstTwitter.Items.Add("Sr.No: " + tweetcount + "\n" + tweet.User.Name + "\n" + tweet.User.ScreenName + "\n" + "https://twitter.com/intent/retweet?tweet_id=" + tweet.Id);
                    tweetList[tweetcount] = new TweetList();
                    tweetList[tweetcount].profilePic = Resources.twitter;
                    tweetList[tweetcount].twitterAccount = tweet.User.Name;
                    tweetList[tweetcount].tweetBody = tweet.Text;
                    tweetList[tweetcount].tweetDateTime = tweet.CreatedDate.ToString();
                    //add info to flowlayout
                    if (flowLayoutPanel1.Controls.Count < 0)
                    {
                        flowLayoutPanel1.Controls.Clear();
                    }
                    else
                        flowLayoutPanel1.Controls.Add(tweetList[tweetcount]);
                    tweetcount++;
                    
                }
                catch { 
                    //empty unless needed
                }
            }            
        }

        private void BtnTwitter_Click(object sender, EventArgs e)
        {
            XElement contacts = XElement.Parse(
            @"<Contacts>
                <Contact>
                    <Name>Patrick Hines</Name>
                    <Phone Type=""home"">206-555-0144</Phone>
                    <Phone Type=""work"">425-555-0145</Phone>
                    <Address>
                    <Street1>123 Main St</Street1>
                    <City>Mercer Island</City>
                    <State>WA</State>
                    <Postal>68042</Postal>
                    </Address>
                    <NetWorth>10</NetWorth>
                </Contact>
                <Contact>
                    <Name>Gretchen Rivas</Name>
                    <Phone Type=""mobile"">206-555-0163</Phone>
                    <Address>
                    <Street1>123 Main St</Street1>
                    <City>Mercer Island</City>
                    <State>WA</State>
                    <Postal>68042</Postal>
                    </Address>
                    <NetWorth>11</NetWorth>
                </Contact>
            </Contacts>");
            lblTest.Text = contacts.ToString();

        }

        private void populateTweets()
        {
            ////Populate tweets
            //TweetList[] tweetList = new TweetList[10];
            ////Loop fir each tweet
            //for (int i = 0; i < tweetList.Length; i++)
            //{
            //    tweetList[i] = new TweetList();
            //    tweetList[i].profilePic = Resources.twitter;
            //    tweetList[i].twitterAccount = "@Some Tweeter Account";
            //    tweetList[i].tweetBody = "Some Tweets";
            //    tweetList[i].tweetDateTime = "Date posted";
            //    //add info to flowlayout
            //    if (flowLayoutPanel1.Controls.Count < 0)
            //    {
            //        flowLayoutPanel1.Controls.Clear();
            //    }
            //    else
            //        flowLayoutPanel1.Controls.Add(tweetList[i]);
            //}
        }

        private void populateWeather()
        {

            string json = (new WebClient()).DownloadString("http://api.openweathermap.org/data/2.5/weather?id=6167863&appid=3f2635c452b15905dfc6b23c042f2a24&units=metric");
            var getWeatherFromAPI = new JavaScriptSerializer().Deserialize<GetWeather>(json);
            //lblTest.Text = getWeatherFromAPI.main.temp.ToString();
            //Populate weather
            GetWeather2 weatherList = new GetWeather2();                        
                weatherList = new GetWeather2();
                weatherList.weatherPic = Resources.weather;
                weatherList.weatherCity = getWeatherFromAPI.name;
                weatherList.weatherRealTemp = "Feels like " + getWeatherFromAPI.main.feels_like.ToString() + "°";
                weatherList.weatherMinMax = "Min " + getWeatherFromAPI.main.temp_min + "°" +
                    " Max" + getWeatherFromAPI.main.temp_max + "°";
                weatherList.weatherTemp = getWeatherFromAPI.main.temp.ToString() + "°C";
            //add info to flowlayout
            flowLayoutPanel2.Controls.Add(weatherList);
        }
        

        private void testRSS()
        {
            XElement contacts = XElement.Parse(
            @"<Contacts>
                <Contact>
                    <Name>Patrick Hines</Name>
                    <Phone Type=""home"">206-555-0144</Phone>
                    <Phone Type=""work"">425-555-0145</Phone>
                    <Address>
                    <Street1>123 Main St</Street1>
                    <City>Mercer Island</City>
                    <State>WA</State>
                    <Postal>68042</Postal>
                    </Address>
                    <NetWorth>10</NetWorth>
                </Contact>
                <Contact>
                    <Name>Gretchen Rivas</Name>
                    <Phone Type=""mobile"">206-555-0163</Phone>
                    <Address>
                    <Street1>123 Main St</Street1>
                    <City>Mercer Island</City>
                    <State>WA</State>
                    <Postal>68042</Postal>
                    </Address>
                    <NetWorth>11</NetWorth>
                </Contact>
            </Contacts>");
            lblTest.Text = contacts.ToString();
        }


    }
}
