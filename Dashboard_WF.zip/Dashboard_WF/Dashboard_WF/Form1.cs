﻿using System;
using System.Collections.Generic;
using System.Windows.Forms;
using System.Web.Script.Serialization; //Project
using System.Net; //Project
using TweetSharp; //Project
using Dashboard_WF.Properties; //Project
using CodeHollow.FeedReader; //Project
using System.IO; //Project
using System.Drawing;

namespace Dashboard_WF
{
    public partial class frmMain : Form
    {
        public static string _consumerKey = "8RBVTo0OXpRNksxwucrh1L3Lc"; // Your key
        public static string _consumerSecret = "gVN9iY1mpJgtZtXW4be2raIFsWLumHpMIjdrxrmoB6thFp22LM"; // Your key  
        public static string _accessToken = "50301489-GNFMaQnW2iiUK64nZZC3AtQ7ecV31CCN295zi3Ecs"; // Your key  
        public static string _accessTokenSecret = "OKWZ8m3ftwZltykAgLZIQr1kDdNJ0YJnJHFqDUY9MEKGQ"; // Your key  

        public frmMain()
        {
            NewTheme();
            InitializeComponent();            
            getTwitter();
            populateWeather();
            populateRSS();            
        }

        public void getInfo()
        {
            //Here I should add the default or last location.
        }        

        private void getTwitter()
        {
            try
            {
                lblTwtLastUpdate.Text = DateTime.Now.ToShortTimeString();
                TwitterService twitterService = new TwitterService(_consumerKey, _consumerSecret);
                twitterService.AuthenticateWith(_accessToken, _accessTokenSecret);

                
                string hashtag = "#" + txtHashTest.Text;
                int tweetcount = 1;
                string selected = this.comboTweetLimit.GetItemText(this.comboTweetLimit.SelectedItem);
                int tweetLimit = Convert.ToInt32(selected);
                TweetList[] tweetList = new TweetList[tweetLimit];
                var tweets_search = twitterService.Search(new SearchOptions { Q = hashtag, Resulttype = TwitterSearchResultType.Recent, Count = tweetLimit });

                List<TwitterStatus> resultList = new List<TwitterStatus>(tweets_search.Statuses);
                foreach (var tweet in tweets_search.Statuses)
                {
                    try
                    {
                        tweetList[tweetcount] = new TweetList();
                        WebClient wc = new WebClient();
                        byte[] bytes = wc.DownloadData(tweet.User.ProfileImageUrl);
                        MemoryStream ms = new MemoryStream(bytes);
                        tweetList[tweetcount].profilePic = System.Drawing.Image.FromStream(ms);
                        tweetList[tweetcount].twitterAccount = tweet.User.Name;
                        tweetList[tweetcount].tweetBody = tweet.Text;
                        tweetList[tweetcount].tweetDateTime = tweet.CreatedDate.ToString();

                        //add info to flowlayout
                        if (flowLayoutPanel1.Controls.Count < 0)
                        {
                            flowLayoutPanel1.Controls.Clear();
                        }
                        else
                            flowLayoutPanel1.Controls.Add(tweetList[tweetcount]);
                        //tweetcount++;

                    }
                    catch (OverflowException e)
                    {
                        Console.WriteLine("Error caught: {0}", e);
                    }

                    catch (IndexOutOfRangeException ex)
                    {
                        Console.WriteLine("Error caught: {0}", ex);
                    }
                }
            }
            catch (OverflowException e)
            {
                Console.WriteLine("Error caught: {0}", e);
            }

            catch (IndexOutOfRangeException ex)
            {
                Console.WriteLine("Error caught: {0}", ex);
            }
                      
        }

        private void populateWeather()
        {
            lblWeLastUpdate.Text = DateTime.Now.ToShortTimeString();
            string json = (new WebClient()).DownloadString("http://api.openweathermap.org/data/2.5/weather?id=6167863&appid=3f2635c452b15905dfc6b23c042f2a24&units=metric");
            var getWeatherFromAPI = new JavaScriptSerializer().Deserialize<GetWeather>(json);
        
            //Populate weather
            GetWeather2 weatherList = new GetWeather2();                        
                weatherList = new GetWeather2();
                weatherList.weatherPic = Resources.weather_2;
                weatherList.weatherCity = getWeatherFromAPI.name;
                weatherList.weatherRealTemp = "Feels like " + getWeatherFromAPI.main.feels_like.ToString() + "°";
                weatherList.weatherMinMax = "Min " + getWeatherFromAPI.main.temp_min + "°" +
                    " Max" + getWeatherFromAPI.main.temp_max + "°";
                weatherList.weatherTemp = getWeatherFromAPI.main.temp.ToString() + "°C";
            //add info to flowlayout
            flowLayoutPanel2.Controls.Add(weatherList);
        }
        

        private void populateRSS()
        {
            lblRSSLastUpdate.Text = DateTime.Now.ToShortTimeString();
            var feed = FeedReader.Read("http://feeds.feedburner.com/Mobilecrunch");

            //Populate RSS
            GetRSS rssNewsList = new GetRSS();            

            foreach (var item in feed.Items)
            {
                rssNewsList = new GetRSS();                
                rssNewsList.rssTitle = item.Title;
                rssNewsList.rssDescription = item.Description;
                rssNewsList.rssLink = item.Link;
                rssNewsList.rssDate = item.PublishingDateString;
                
                //add info to flowlayout
                if (flowLayoutPanel1.Controls.Count < 0)
                {
                    flowLayoutPanel1.Controls.Clear();
                }
                else
                    flowLayoutPanelRSS.Controls.Add(rssNewsList);
                //rsscount++;
            }
        }

// ================== UPDATE BUTTONS START ========================= 

        private void BtnWeUpdate_Click(object sender, EventArgs e)        {
            
            populateWeather();            
        }

        private void BtnTwtUpdate_Click(object sender, EventArgs e)
        {
            flowLayoutPanel1.Controls.Clear();
            getTwitter();            
        }

        private void BtnRSSUpdate_Click(object sender, EventArgs e)
        {
            populateRSS();
        }

// ================== UPDATE BUTTONS END ========================= 

// ================== TODO MODULE START =========================    

        private void LblAddNote_Click(object sender, EventArgs e)
        {
            populateToDo();
            txtAddNote.Clear();
            txtAddNote.Focus();
        }

        private void populateToDo()
        {
            //Create note
            ToDo todolist = new ToDo();
            todolist.noteContent = txtAddNote.Text;
            todolist.noteDate = DateTime.Now.ToShortTimeString();
            flowLayoutPanelToDo.Controls.Add(todolist);            
        }

        // ================== TODO MODULE END =========================

        private void NewTheme()
        {
            this.BackColor = ColorTranslator.FromHtml("#1b262c");
        }        
    }
}




// DOCS

    //Twitter

//tweet.User.ScreenName;  
//tweet.User.Name;   
//tweet.Text; // Tweet text  
//tweet.RetweetCount; //No of retweet on twitter  
//tweet.User.FavouritesCount; //No of Fav mark on twitter  
//tweet.User.ProfileImageUrl; //Profile Image of Tweet  
//tweet.CreatedDate; //For Tweet posted time  
//"https://twitter.com/intent/retweet?tweet_id=" + tweet.Id;  //For Retweet  
//"https://twitter.com/intent/tweet?in_reply_to=" + tweet.Id; //For Reply  
//"https://twitter.com/intent/favorite?tweet_id=" + tweet.Id; //For Favorite  

//Above are the things we can also get using TweetSharp.  
//Console.WriteLine("Sr.No: " + tweetcount + "\n" + tweet.User.Name + "\n" + tweet.User.ScreenName + "\n" + "https://twitter.com/intent/retweet?tweet_id=" + tweet.Id);
//lstTwitter.Items.Add("Sr.No: " + tweetcount + "\n" + tweet.User.Name + "\n" + tweet.User.ScreenName + "\n" + "https://twitter.com/intent/retweet?tweet_id=" + tweet.Id);
//Resulttype can be TwitterSearchResultType.Popular or TwitterSearchResultType.Mixed or TwitterSearchResultType.Recent  


