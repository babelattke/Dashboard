﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Web.Script.Serialization; //Project
using System.Net; //Project
using Newtonsoft.Json; //Project
using TweetSharp; //Project

namespace Dashboard_WF
{
    public partial class frmMain : Form
    {
        public static string _consumerKey = "8RBVTo0OXpRNksxwucrh1L3Lc"; // Your key
        public static string _consumerSecret = "gVN9iY1mpJgtZtXW4be2raIFsWLumHpMIjdrxrmoB6thFp22LM"; // Your key  
        public static string _accessToken = "50301489-GNFMaQnW2iiUK64nZZC3AtQ7ecV31CCN295zi3Ecs"; // Your key  
        public static string _accessTokenSecret = "OKWZ8m3ftwZltykAgLZIQr1kDdNJ0YJnJHFqDUY9MEKGQ"; // Your key  

        public frmMain()
        {
            InitializeComponent();
            //getInfo(); Uncomment once I have some real code in there
        }

        public void getInfo()
        {
            //Here I should add the default or last location.
        }

        private void BtnRefresh_Click(object sender, EventArgs e)
        {
            //getInfo();
            string json = (new WebClient()).DownloadString("http://api.openweathermap.org/data/2.5/weather?id=6167863&appid=3f2635c452b15905dfc6b23c042f2a24");            
            var example2 = new JavaScriptSerializer().Deserialize<GetWeather>(json);
            lblTest.Text = example2.main.temp.ToString();
            
        }

        private void getTwitter()
        {
            
            TwitterService twitterService = new TwitterService(_consumerKey, _consumerSecret);
            twitterService.AuthenticateWith(_accessToken, _accessTokenSecret);

            int tweetcount = 1;
            var tweets_search = twitterService.Search(new SearchOptions { Q = "#ebgames", Resulttype = TwitterSearchResultType.Recent, Count = 10 });
            //Resulttype can be TwitterSearchResultType.Popular or TwitterSearchResultType.Mixed or TwitterSearchResultType.Recent  
            List<TwitterStatus> resultList = new List<TwitterStatus>(tweets_search.Statuses);
            foreach (var tweet in tweets_search.Statuses)
            {
                try
                {
                    //tweet.User.ScreenName;  
                    //tweet.User.Name;   
                    //tweet.Text; // Tweet text  
                    //tweet.RetweetCount; //No of retweet on twitter  
                    //tweet.User.FavouritesCount; //No of Fav mark on twitter  
                    //tweet.User.ProfileImageUrl; //Profile Image of Tweet  
                    //tweet.CreatedDate; //For Tweet posted time  
                    //"https://twitter.com/intent/retweet?tweet_id=" + tweet.Id;  //For Retweet  
                    //"https://twitter.com/intent/tweet?in_reply_to=" + tweet.Id; //For Reply  
                    //"https://twitter.com/intent/favorite?tweet_id=" + tweet.Id; //For Favorite  

                    //Above are the things we can also get using TweetSharp.  
                    //Console.WriteLine("Sr.No: " + tweetcount + "\n" + tweet.User.Name + "\n" + tweet.User.ScreenName + "\n" + "https://twitter.com/intent/retweet?tweet_id=" + tweet.Id);
                    txtTest.Text = "Sr.No: " + tweetcount + "\n" + tweet.User.Name + "\n" + tweet.User.ScreenName + "\n" + "https://twitter.com/intent/retweet?tweet_id=" + tweet.Id;
                    tweetcount++;
                    lblTest.Text = "Clicked in try";
                }
                catch { lblTest.Text = "Clicked in catch"; }
            }
            //Console.ReadLine();
        }

        private void BtnTwitter_Click(object sender, EventArgs e)
        {
            getTwitter();

        }
    }
}
