﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Drawing;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Dashboard_WF
{
    public partial class ToDo : UserControl
    {
        public ToDo()
        {
            InitializeComponent();
        }

        private string NoteDate;
        private string NoteContent;
        private string Mainbkg;
        private string Notebkg;        

        public string noteDate
        {
            get { return NoteDate; }
            set { NoteDate = value; lblDate.Text = value; }
        }

        public string noteContent
        {
            get { return NoteContent; }
            set { NoteContent = value; txtNote.Text = value; }
        }
        

        private void LblCLose_Click(object sender, EventArgs e)
        {
            this.Dispose();
        }

        private void LblEdit_Click(object sender, EventArgs e)
        {
            txtNote.ReadOnly = false;
            txtNote.BackColor = System.Drawing.Color.White;
            txtNote.SelectionStart = 0;
            txtNote.SelectionLength = txtNote.Text.Length;
            lblEdit.Visible = false;
            lblSave.Visible = true;
        }

        private void LblSave_Click(object sender, EventArgs e)
        {
            txtNote.ReadOnly = true;
            txtNote.BackColor = System.Drawing.Color.Gold;
            lblEdit.Visible = true;
            lblSave.Visible = false;
            lblDate.Text = DateTime.Now.ToShortTimeString();
        }
    }
}
