﻿namespace Dashboard_WF
{
    partial class TweetList
    {
        /// <summary> 
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary> 
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Component Designer generated code

        /// <summary> 
        /// Required method for Designer support - do not modify 
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.lblTwitterAccount = new System.Windows.Forms.Label();
            this.txtTweetBody = new System.Windows.Forms.TextBox();
            this.lblTweetDateTime = new System.Windows.Forms.Label();
            this.imgTweetProfile = new System.Windows.Forms.PictureBox();
            ((System.ComponentModel.ISupportInitialize)(this.imgTweetProfile)).BeginInit();
            this.SuspendLayout();
            // 
            // lblTwitterAccount
            // 
            this.lblTwitterAccount.Font = new System.Drawing.Font("Microsoft JhengHei", 12.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblTwitterAccount.Location = new System.Drawing.Point(109, 3);
            this.lblTwitterAccount.Name = "lblTwitterAccount";
            this.lblTwitterAccount.Size = new System.Drawing.Size(240, 23);
            this.lblTwitterAccount.TabIndex = 1;
            this.lblTwitterAccount.Text = "@SomeTwitterAccount";
            // 
            // txtTweetBody
            // 
            this.txtTweetBody.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.txtTweetBody.Font = new System.Drawing.Font("Microsoft JhengHei", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtTweetBody.Location = new System.Drawing.Point(113, 29);
            this.txtTweetBody.Multiline = true;
            this.txtTweetBody.Name = "txtTweetBody";
            this.txtTweetBody.ReadOnly = true;
            this.txtTweetBody.Size = new System.Drawing.Size(285, 74);
            this.txtTweetBody.TabIndex = 2;
            this.txtTweetBody.Text = "@TweetText";
            // 
            // lblTweetDateTime
            // 
            this.lblTweetDateTime.AutoSize = true;
            this.lblTweetDateTime.Font = new System.Drawing.Font("Microsoft JhengHei", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblTweetDateTime.Location = new System.Drawing.Point(241, 106);
            this.lblTweetDateTime.Name = "lblTweetDateTime";
            this.lblTweetDateTime.Size = new System.Drawing.Size(157, 15);
            this.lblTweetDateTime.TabIndex = 3;
            this.lblTweetDateTime.Text = "@Date and time of the tweet";
            // 
            // imgTweetProfile
            // 
            this.imgTweetProfile.Location = new System.Drawing.Point(3, 3);
            this.imgTweetProfile.Name = "imgTweetProfile";
            this.imgTweetProfile.Size = new System.Drawing.Size(104, 100);
            this.imgTweetProfile.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.imgTweetProfile.TabIndex = 0;
            this.imgTweetProfile.TabStop = false;
            // 
            // TweetList
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.Controls.Add(this.lblTweetDateTime);
            this.Controls.Add(this.txtTweetBody);
            this.Controls.Add(this.lblTwitterAccount);
            this.Controls.Add(this.imgTweetProfile);
            this.Name = "TweetList";
            this.Size = new System.Drawing.Size(401, 123);
            ((System.ComponentModel.ISupportInitialize)(this.imgTweetProfile)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.PictureBox imgTweetProfile;
        private System.Windows.Forms.Label lblTwitterAccount;
        private System.Windows.Forms.TextBox txtTweetBody;
        private System.Windows.Forms.Label lblTweetDateTime;
    }
}
