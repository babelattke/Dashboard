﻿namespace Dashboard_WF
{
    partial class GetWeather2
    {
        /// <summary> 
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary> 
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Component Designer generated code

        /// <summary> 
        /// Required method for Designer support - do not modify 
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.lblCity = new System.Windows.Forms.Label();
            this.lblCurrentTemp = new System.Windows.Forms.Label();
            this.lblMinMaxTemp = new System.Windows.Forms.Label();
            this.lblRealTemp = new System.Windows.Forms.Label();
            this.imgWeather = new System.Windows.Forms.PictureBox();
            ((System.ComponentModel.ISupportInitialize)(this.imgWeather)).BeginInit();
            this.SuspendLayout();
            // 
            // lblCity
            // 
            this.lblCity.AutoSize = true;
            this.lblCity.Location = new System.Drawing.Point(123, 18);
            this.lblCity.Name = "lblCity";
            this.lblCity.Size = new System.Drawing.Size(35, 13);
            this.lblCity.TabIndex = 1;
            this.lblCity.Text = "label1";
            // 
            // lblCurrentTemp
            // 
            this.lblCurrentTemp.AutoSize = true;
            this.lblCurrentTemp.Location = new System.Drawing.Point(123, 42);
            this.lblCurrentTemp.Name = "lblCurrentTemp";
            this.lblCurrentTemp.Size = new System.Drawing.Size(35, 13);
            this.lblCurrentTemp.TabIndex = 2;
            this.lblCurrentTemp.Text = "label2";
            // 
            // lblMinMaxTemp
            // 
            this.lblMinMaxTemp.AutoSize = true;
            this.lblMinMaxTemp.Location = new System.Drawing.Point(123, 70);
            this.lblMinMaxTemp.Name = "lblMinMaxTemp";
            this.lblMinMaxTemp.Size = new System.Drawing.Size(35, 13);
            this.lblMinMaxTemp.TabIndex = 3;
            this.lblMinMaxTemp.Text = "label3";
            // 
            // lblRealTemp
            // 
            this.lblRealTemp.AutoSize = true;
            this.lblRealTemp.Location = new System.Drawing.Point(122, 90);
            this.lblRealTemp.Name = "lblRealTemp";
            this.lblRealTemp.Size = new System.Drawing.Size(35, 13);
            this.lblRealTemp.TabIndex = 4;
            this.lblRealTemp.Text = "label4";
            // 
            // imgWeather
            // 
            this.imgWeather.Location = new System.Drawing.Point(4, 4);
            this.imgWeather.Name = "imgWeather";
            this.imgWeather.Size = new System.Drawing.Size(112, 106);
            this.imgWeather.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.imgWeather.TabIndex = 0;
            this.imgWeather.TabStop = false;
            // 
            // GetWeather2
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.Controls.Add(this.lblRealTemp);
            this.Controls.Add(this.lblMinMaxTemp);
            this.Controls.Add(this.lblCurrentTemp);
            this.Controls.Add(this.lblCity);
            this.Controls.Add(this.imgWeather);
            this.Name = "GetWeather2";
            this.Size = new System.Drawing.Size(267, 115);
            ((System.ComponentModel.ISupportInitialize)(this.imgWeather)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.PictureBox imgWeather;
        private System.Windows.Forms.Label lblCity;
        private System.Windows.Forms.Label lblCurrentTemp;
        private System.Windows.Forms.Label lblMinMaxTemp;
        private System.Windows.Forms.Label lblRealTemp;
    }
}
