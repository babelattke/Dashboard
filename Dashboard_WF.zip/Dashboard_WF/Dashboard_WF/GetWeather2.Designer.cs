﻿namespace Dashboard_WF
{
    partial class GetWeather2
    {
        /// <summary> 
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary> 
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Component Designer generated code

        /// <summary> 
        /// Required method for Designer support - do not modify 
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.lblCity = new System.Windows.Forms.Label();
            this.lblCurrentTemp = new System.Windows.Forms.Label();
            this.lblMinMaxTemp = new System.Windows.Forms.Label();
            this.lblRealTemp = new System.Windows.Forms.Label();
            this.imgWeather = new System.Windows.Forms.PictureBox();
            ((System.ComponentModel.ISupportInitialize)(this.imgWeather)).BeginInit();
            this.SuspendLayout();
            // 
            // lblCity
            // 
            this.lblCity.AutoSize = true;
            this.lblCity.Font = new System.Drawing.Font("Microsoft JhengHei", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblCity.Location = new System.Drawing.Point(123, 4);
            this.lblCity.Name = "lblCity";
            this.lblCity.Size = new System.Drawing.Size(38, 20);
            this.lblCity.TabIndex = 1;
            this.lblCity.Text = "City";
            // 
            // lblCurrentTemp
            // 
            this.lblCurrentTemp.AutoSize = true;
            this.lblCurrentTemp.Font = new System.Drawing.Font("Microsoft JhengHei", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblCurrentTemp.Location = new System.Drawing.Point(123, 35);
            this.lblCurrentTemp.Name = "lblCurrentTemp";
            this.lblCurrentTemp.Size = new System.Drawing.Size(146, 26);
            this.lblCurrentTemp.TabIndex = 2;
            this.lblCurrentTemp.Text = "CurrentTemp";
            // 
            // lblMinMaxTemp
            // 
            this.lblMinMaxTemp.AutoSize = true;
            this.lblMinMaxTemp.Font = new System.Drawing.Font("Microsoft JhengHei", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblMinMaxTemp.Location = new System.Drawing.Point(123, 70);
            this.lblMinMaxTemp.Name = "lblMinMaxTemp";
            this.lblMinMaxTemp.Size = new System.Drawing.Size(50, 15);
            this.lblMinMaxTemp.TabIndex = 3;
            this.lblMinMaxTemp.Text = "MinMax";
            // 
            // lblRealTemp
            // 
            this.lblRealTemp.AutoSize = true;
            this.lblRealTemp.Font = new System.Drawing.Font("Microsoft JhengHei", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblRealTemp.Location = new System.Drawing.Point(123, 90);
            this.lblRealTemp.Name = "lblRealTemp";
            this.lblRealTemp.Size = new System.Drawing.Size(58, 15);
            this.lblRealTemp.TabIndex = 4;
            this.lblRealTemp.Text = "RealTemp";
            // 
            // imgWeather
            // 
            this.imgWeather.Location = new System.Drawing.Point(4, 4);
            this.imgWeather.Name = "imgWeather";
            this.imgWeather.Size = new System.Drawing.Size(112, 106);
            this.imgWeather.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.imgWeather.TabIndex = 0;
            this.imgWeather.TabStop = false;
            // 
            // GetWeather2
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.Controls.Add(this.lblRealTemp);
            this.Controls.Add(this.lblMinMaxTemp);
            this.Controls.Add(this.lblCurrentTemp);
            this.Controls.Add(this.lblCity);
            this.Controls.Add(this.imgWeather);
            this.Name = "GetWeather2";
            this.Size = new System.Drawing.Size(276, 115);
            ((System.ComponentModel.ISupportInitialize)(this.imgWeather)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.PictureBox imgWeather;
        private System.Windows.Forms.Label lblCity;
        private System.Windows.Forms.Label lblCurrentTemp;
        private System.Windows.Forms.Label lblMinMaxTemp;
        private System.Windows.Forms.Label lblRealTemp;
    }
}
