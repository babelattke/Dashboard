﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Drawing;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Dashboard_WF
{
    public partial class GetRSS : UserControl
    {
        public GetRSS()
        {
            InitializeComponent();
        }

        private string RSSTitle;
        private string RSSDescription;
        private string RSSLink;
        private string RSSDate;
        

        public string rssTitle
        {
            get { return RSSTitle; }
            set { RSSTitle = value; lblTitle.Text = value; }
        }

        public string rssDescription
        {
            get { return RSSDescription; }
            set { RSSDescription = value; txtContent.Text = value; }
        }

        public string rssLink
        {
            get { return RSSLink; }
            set { RSSLink = value; txtLink.Text = value; }
        }

        public string rssDate
        {
            get { return RSSDate; }
            set { RSSDate = value; lblDate.Text = value; }
        }

        

    }
}
